package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.exceptions.*;
import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.repositories.ExpedicionRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExpedicionService {
    @Autowired
    ExpedicionRepository expedicionRepository;

    /**
	 * Verificamos los datos ingresados para crear una nueva expedicion
	 *
	 * @param expedicionEntity Objeto de ExpedicionEntity con los datos nuevos
	 * @return Objeto de ExpedicionEntity con los datos nuevos y su ID.
	 * @throws IllegalOperationException 
	 */
    @Transactional
    public ExpedicionEntity crearExpedicion(ExpedicionEntity expedicionEntity) throws IllegalOperationException {
        log.info("Inicia proceso de creación de la expedicion");
        if(expedicionEntity.getNombre() == null || expedicionEntity.getNombre().isEmpty()) {
            throw new IllegalOperationException("El nombre de la expedición no es válido");
        }
        if(expedicionEntity.getFechaInicio() == null || expedicionEntity.getFechaInicio().isEmpty()) {
            throw new IllegalOperationException("La fecha de inicio no es válida");
        }
        if(expedicionEntity.getFechaFin() == null || expedicionEntity.getFechaFin().isEmpty()) {
            throw new IllegalOperationException("La fecha de fin no es válida");
        }
        if(expedicionEntity.getLugarSalida() == null || expedicionEntity.getLugarSalida().isEmpty()) {
            throw new IllegalOperationException("El lugar de salida no es válido");
        }
        if(expedicionEntity.getLugarLlegada() == null || expedicionEntity.getLugarLlegada().isEmpty()) {
            throw new IllegalOperationException("El lugar de llegada no es válido");
        }
        if(expedicionEntity.getCosto() == null || expedicionEntity.getCosto() < 0) {
            throw new IllegalOperationException("El costo no es válido");
        }
        if(expedicionEntity.getDuracion() <= 0) {
            throw new IllegalOperationException("La duración no es válida");
        }
        log.info("Termina el proceso de crear Cliente");
        return expedicionRepository.save(expedicionEntity);
    }
    
    /**
	 * Buscamos una expedicion dada por un ID
	 *
	 * @param expedicionId identificador de la expedicion a buscar
	 * @return Instancia de ExpedicionEntity que corresponde a la expedicion buscada por su id
	 * @throws EntityNotFoundException 
	 */
    @Transactional
    public ExpedicionEntity getExpedicionPorId(Long expedicionId) throws EntityNotFoundException {
        log.info("Inicia proceso de consulta de la expedición con id = {}", expedicionId);
        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findById(expedicionId);
        if (expedicionEntity.isEmpty()){
            throw new EntityNotFoundException("La expedicion con el id dado no existe");
        }
        log.info("Termina proceso de consultar la expedicion con id = {0}", expedicionId);
        return expedicionEntity.get();
    }

    /**
	 * Buscamos una expedicion dada por su nombre
	 *
	 * @param nombre nombre de la expedicion a buscar
	 * @return Instancia de ExpedicionEntity que corresponde a la expedicion buscada por su nombre
	 * @throws EntityNotFoundException 
	 */
    @Transactional
    public ExpedicionEntity getExpedicionPorNombre(String nombre) throws EntityNotFoundException {
        log.info("Inicia proceso de consulta de la expedición con nombre = {}", nombre);
        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findByNombre(nombre);
        if (expedicionEntity.isEmpty()){
            throw new EntityNotFoundException("No se puede obtener ya que la expedicion con el nombre dado no existe");
        }
        log.info("Termina proceso de consultar la expedicion con nombre = {0}", nombre);
        return expedicionEntity.get();
    }

    /**
	 * Buscamos una expedicion por un rango de precios
	 *
     * @param precioIncial precio inicial del rango
     * @param precioFinal precio final del rango
	 * @return Instancia de ExpedicionEntity que corresponde a la expedicion buscada por su rango de precios
	 * @throws EntityNotFoundException 
	 */
    @Transactional
    public ExpedicionEntity getExpedicionPorPrecio(Long precioIncial, Long precioFinal) throws EntityNotFoundException {
        log.info("Inicia proceso de consulta de la expedición con un rango de precios = {}", precioIncial, "a", precioFinal);
        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findByCostoBetween(precioIncial, precioFinal).stream().findFirst();
        if (expedicionEntity.isEmpty()){
            throw new EntityNotFoundException("No se puede obtener ya que la expedicion con el rango de precios dado no existe");
        }
        log.info("Termina proceso de consultar la expedicion ccon un rango de precios = {}", precioIncial, "a", precioFinal);
        return expedicionEntity.get();
    }

    /**
	 * Buscamos todas las expediciones registradas
	 */
    @Transactional
    public List<ExpedicionEntity> getExpediciones() {
        log.info("Inicia proceso de consultar todas las expediciones");
        return expedicionRepository.findAll();
    }


    /**
	 * Actualizamos la informacion de una expedicion dada
	 *
     * @param expedicionId identificador de la expedicion a actualizar
     * @param expedicion objeto con la nueva informacion de la expedicion
	 * @return Instancia de ExpedicionEntity con los datos actualizados
	 * @throws EntityNotFoundException 
	 */
    @Transactional
    public ExpedicionEntity updateExpedicion(Long expedicionId, ExpedicionEntity expedicion) throws EntityNotFoundException{
        log.info("Inicia el proceso de actualizar una Expedicion por su id = {}", expedicionId);
        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findById(expedicionId);
        if (expedicionEntity.isEmpty()) {
            throw new EntityNotFoundException("No se puede obtener ya que la expedicion con el id dado no existe");
        }
        expedicion.setId(expedicionId);
        return expedicionRepository.save(expedicion);
    }

    /**
	 * Eliminamos una expedicion dada
	 *
     * @param expedicionId identificador de la expedicion a eliminar
	 * @throws EntityNotFoundException 
	 */
    @Transactional
    public void deleteExpedicion(Long expedicionId) throws EntityNotFoundException {
        log.info("Inicia el proceso de eliminar una Expedicion con id {}", expedicionId);
        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findById(expedicionId);
        if (expedicionEntity.isEmpty()) {
            throw new EntityNotFoundException("No se puede eliminar ya que la expedicion con el id dado no existe");
        }
        expedicionRepository.deleteById(expedicionId);
    }

}
