package co.edu.uniandes.dse.Trekking_Back.entities;

import jakarta.persistence.*;
import lombok.Data;
import uk.co.jemos.podam.common.PodamExclude;

import java.util.List;

@Data
@Entity
public class ItinerarioEntity extends BaseEntity {

    // Atributos basicos
    @Column(name = "nombreItinerario", nullable = true) 
    private String nombre;
    
    // Atributos con otras relaciones

    // Relacion multiple con dias itinerario -> Una expedicion tiene multiples dias
    @OneToMany(mappedBy = "itinerario", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("numeroDia ASC")
    @PodamExclude
    private List<DiaItinerarioEntity> dias;

    // Inversa del @OneToOne en ExpedicionEntity.itinerario
    @OneToOne(mappedBy = "itinerario")
    @PodamExclude
    private ExpedicionEntity expedicion;
}