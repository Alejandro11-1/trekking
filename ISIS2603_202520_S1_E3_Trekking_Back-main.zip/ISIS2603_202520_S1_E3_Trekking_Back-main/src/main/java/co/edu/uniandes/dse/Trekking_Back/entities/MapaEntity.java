package co.edu.uniandes.dse.Trekking_Back.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Data;

@Data
@Entity
public class MapaEntity extends BaseEntity {

    // Atributos basicos
    @Column(name = "InicioCordenadas", nullable = true) 
    private String coordenadasInicio;

    @Column(name = "FinCordenadas", nullable = true) 
    private String coordenadasFin;

    @Column(name = "ruta", nullable = true) 
    private String ruta;
}

