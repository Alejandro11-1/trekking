package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.PersonaJuridicaEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.PersonaJuridicaRepository;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
@Service
public class PersonaJuridicaService {

    private static final String ERROR1 = "La persona juridica no existe";

    @Autowired
    private PersonaJuridicaRepository personaJuridicaRepository;

    @Transactional
    public PersonaJuridicaEntity crearPersonaJuridica(PersonaJuridicaEntity pj) throws IllegalOperationException {
        log.info("Inicia creación de persona juridica");
        if (pj.getNombreEmpresa() == null || pj.getNombreEmpresa().isEmpty())
            throw new IllegalOperationException("El nombre de la empresa no es valido");

        if (personaJuridicaRepository.findByNombreEmpresa(pj.getNombreEmpresa()).isPresent())
            throw new IllegalOperationException("Ya existe una empresa con el mismo nombre");

        return personaJuridicaRepository.save(pj);
    }

    @Transactional
    public PersonaJuridicaEntity getPersonaJuridica(Long id) throws EntityNotFoundException {
        log.info("Consulta persona juridica id={}", id);
        return personaJuridicaRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(ERROR1));
    }

    @Transactional
    public List<PersonaJuridicaEntity> getPersonasJuridicas() {
        log.info("Consulta todas las personas juridicas");
        return personaJuridicaRepository.findAll();
    }

    @Transactional
    public PersonaJuridicaEntity getPorNombreEmpresa(String nombreEmpresa)
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Consulta persona juridica por nombreEmpresa={}", nombreEmpresa);
        if (nombreEmpresa == null || nombreEmpresa.isEmpty())
            throw new IllegalOperationException("Debe indicar un nombre de empresa");
        return personaJuridicaRepository.findByNombreEmpresa(nombreEmpresa)
                .orElseThrow(() -> new EntityNotFoundException(ERROR1));
    }

    @Transactional
    public PersonaJuridicaEntity updatePersonaJuridica(Long id, PersonaJuridicaEntity pj)
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Actualiza persona juridica id={}", id);
        if (!personaJuridicaRepository.existsById(id))
            throw new EntityNotFoundException(ERROR1);

        if (pj.getNombreEmpresa() == null || pj.getNombreEmpresa().isEmpty())
            throw new IllegalOperationException("El nombre de la empresa no es valido");

        Optional<PersonaJuridicaEntity> clash = personaJuridicaRepository.findByNombreEmpresa(pj.getNombreEmpresa());
        if (clash.isPresent() && !clash.get().getId().equals(id))
            throw new IllegalOperationException("Ya existe otra empresa con el mismo nombre");

        pj.setId(id);
        return personaJuridicaRepository.save(pj);
    }

    @Transactional
    public void deletePersonaJuridica(Long id) throws EntityNotFoundException {
        log.info("Elimina persona juridica id={}", id);
        if (!personaJuridicaRepository.existsById(id))
            throw new EntityNotFoundException(ERROR1);
        personaJuridicaRepository.deleteById(id);
    }
}

