package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.ClienteEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.ClienteRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ImagenRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ClienteService {

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    ImagenRepository imagenRepository;

    @Transactional
    public ClienteEntity createCliente(ClienteEntity clienteEntity) throws IllegalOperationException {
        log.info("Inicia proceso de creación del cliente");

        if (clienteEntity.getIdCedula() == null || clienteEntity.getIdCedula().isEmpty())
            throw new IllegalOperationException("La cédula no puede ser nula o vacía");

        Optional<ClienteEntity> clienteByCedula = clienteRepository.findByIdCedula(clienteEntity.getIdCedula());
        if (clienteByCedula.isPresent())
            throw new IllegalOperationException("Ya existe un cliente con esa cédula");
        if (clienteEntity.getImagen() == null)
            throw new IllegalOperationException("La imagen no puede ser nula");
        if (clienteEntity.getImagen().getId() != null) {
            Optional<ImagenEntity> imagenEntity = imagenRepository.findById(clienteEntity.getImagen().getId());
            if (imagenEntity.isEmpty())
                throw new IllegalOperationException("La imagen no existe");
            clienteEntity.setImagen(imagenEntity.get());
        } else {
            ImagenEntity nuevaImagen = imagenRepository.save(clienteEntity.getImagen());
            clienteEntity.setImagen(nuevaImagen);
        }

        log.info("Termina proceso de creación del cliente");
        return clienteRepository.save(clienteEntity);
    }

    @Transactional
    public List<ClienteEntity> getClientes() {
        log.info("Inicia proceso de consultar todos los clientes");
        return clienteRepository.findAll();
    }

    @Transactional
    public ClienteEntity getCliente(Long clienteId) throws EntityNotFoundException {
        log.info("Inicia proceso de consultar el cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("No se encuentra un cliente registrado con ese id");
        log.info("Termina proceso de consultar el cliente con id = {0}", clienteId);
        return clienteEntity.get();
    }

    @Transactional
    public ClienteEntity updateCliente(Long clienteId, ClienteEntity cliente) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de actualizar el cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("No se puede actualizar ya que no se encontro un cliente con el id dado");

        if (cliente.getIdCedula() == null || cliente.getIdCedula().isEmpty())
            throw new IllegalOperationException("La cédula no puede ser nula o vacía");

        Optional<ClienteEntity> clienteByCedula = clienteRepository.findByIdCedula(cliente.getIdCedula());
        if (clienteByCedula.isPresent() && !clienteByCedula.get().getId().equals(clienteId))
            throw new IllegalOperationException("Ya existe un cliente con esa cédula");
        if (cliente.getImagen() == null)
            throw new IllegalOperationException("La imagen no puede ser nula");
        if (cliente.getImagen().getId() != null) {
            Optional<ImagenEntity> imagenEntity = imagenRepository.findById(cliente.getImagen().getId());
            if (imagenEntity.isEmpty())
                throw new IllegalOperationException("La imagen no existe");
            cliente.setImagen(imagenEntity.get());
        } else {
            ImagenEntity nuevaImagen = imagenRepository.save(cliente.getImagen());
            cliente.setImagen(nuevaImagen);
        }

        cliente.setId(clienteId);
        log.info("Termina proceso de actualizar el cliente con id = {0}", clienteId);
        return clienteRepository.save(cliente);
    }

    @Transactional
    public void deleteCliente(Long clienteId) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de borrar el cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("No se puede eliminar ya que no se encontro un cliente con el id dado");
        clienteRepository.deleteById(clienteId);
        log.info("Termina proceso de borrar el cliente con id = {0}", clienteId);
    }
}