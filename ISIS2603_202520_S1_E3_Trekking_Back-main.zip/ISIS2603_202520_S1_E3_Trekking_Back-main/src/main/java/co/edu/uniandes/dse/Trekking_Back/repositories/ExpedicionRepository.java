package co.edu.uniandes.dse.Trekking_Back.repositories;

import co.edu.uniandes.dse.Trekking_Back.entities.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ExpedicionRepository extends JpaRepository<ExpedicionEntity, Long> {

    // Busqueda por atributos
    Optional<ExpedicionEntity> findByNombre(String nombre);
    List<ExpedicionEntity> findByNombreContainingIgnoreCase(String nombre);

    List<ExpedicionEntity> findByLugarSalidaContainingIgnoreCase(String lugarSalida);
    List<ExpedicionEntity> findByLugarLlegadaContainingIgnoreCase(String lugarLlegada);

    List<ExpedicionEntity> findByCostoBetween(Long min, Long max);

    // Relacion N:1 con Oferente
    List<ExpedicionEntity> findByOferente(OferenteEntity oferente);
    List<ExpedicionEntity> findByOferenteId(Long oferenteId);

    // Relación 1:1 con Mapa
    List<ExpedicionEntity> findByMapa(MapaEntity mapa);

    // Relacion 1:N con Seguridad
    List<ExpedicionEntity> findDistinctBySeguridadNombreContainingIgnoreCase(String nombre);
    List<ExpedicionEntity> findDistinctBySeguridadPrecioBetween(Long min, Long max);

    // Relacion M:N con DiaItinerario

    List<ExpedicionEntity> findDistinctByItinerario_Dias_NumeroDia(Integer numeroDia);
    List<ExpedicionEntity> findDistinctByItinerario_Dias_AlojamientoContainingIgnoreCase(String alojamiento);
    List<ExpedicionEntity> findDistinctByItinerario_Dias_ActividadesContainingIgnoreCase(String actividades);
    List<ExpedicionEntity> findDistinctByItinerario_Dias_ComidaContainingIgnoreCase(String comida);

}