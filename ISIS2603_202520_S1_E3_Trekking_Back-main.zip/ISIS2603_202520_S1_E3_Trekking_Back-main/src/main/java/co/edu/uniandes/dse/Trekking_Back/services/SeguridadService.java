package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.ExpedicionRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.SeguridadRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SeguridadService {

    private static final String ERROR1 = "El seguro no existe";

    @Autowired
    private SeguridadRepository seguridadRepository;

    @Autowired
    private ExpedicionRepository expedicionRepository;

    @Transactional
    public SeguridadEntity crearSeguridad(SeguridadEntity seguridad)
            throws IllegalOperationException {
        log.info("Inicia creación de seguridad");
        validarSeguridad(seguridad);

        // Verificar que la expedición asociada exista
        if (seguridad.getExpedicion() == null || seguridad.getExpedicion().getId() == null
                || !expedicionRepository.existsById(seguridad.getExpedicion().getId())) {
            throw new IllegalOperationException("La seguridad debe estar asociada a una expedición válida");
        }
        return seguridadRepository.save(seguridad);
    }

    @Transactional
    public SeguridadEntity getSeguridadPorId(Long seguridadId) throws EntityNotFoundException {
        log.info("Consulta seguridad id={}", seguridadId);
        return seguridadRepository.findById(seguridadId)
                .orElseThrow(() -> new EntityNotFoundException(ERROR1));
    }

    @Transactional
    public List<SeguridadEntity> getSegurosPorExpedicion(Long expedicionId) throws EntityNotFoundException {
        log.info("Consulta seguros por expedición id={}", expedicionId);
        if (!expedicionRepository.existsById(expedicionId))
            throw new EntityNotFoundException("La expedición no existe");
        return seguridadRepository.findByExpedicionId(expedicionId);
    }

    @Transactional
    public List<SeguridadEntity> buscarPorNombre(String nombre) {
        log.info("Búsqueda de seguros por nombre ~ {}", nombre);
        return seguridadRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Transactional
    public List<SeguridadEntity> buscarPorPrecio(Long min, Long max) {
        log.info("Búsqueda de seguros por precio entre {} y {}", min, max);
        return seguridadRepository.findByPrecioBetween(min, max);
    }

    /**
	 * Buscamos todas las seguridades registradas
	 */
    @Transactional
    public List<SeguridadEntity> getSeguridades() {
        log.info("Inicia proceso de consultar todos los planes de seguridad");
        return seguridadRepository.findAll();
    }

    @Transactional
    public SeguridadEntity updateSeguridad(Long seguridadId, SeguridadEntity seguridad)
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Actualiza seguridad id={}", seguridadId);
        if (!seguridadRepository.existsById(seguridadId))
            throw new EntityNotFoundException(ERROR1);

        validarSeguridad(seguridad);
        seguridad.setId(seguridadId);
        return seguridadRepository.save(seguridad);
    }

    @Transactional
    public void deleteSeguridad(Long seguridadId) throws EntityNotFoundException {
        log.info("Elimina seguridad id={}", seguridadId);
        if (!seguridadRepository.existsById(seguridadId))
            throw new EntityNotFoundException(ERROR1);
        seguridadRepository.deleteById(seguridadId);
    }

    private void validarSeguridad(SeguridadEntity s) throws IllegalOperationException {
        if (s.getNombre() == null || s.getNombre().isBlank())
            throw new IllegalOperationException("El nombre no es válido");
        if (s.getCobertura() == null || s.getCobertura().isBlank())
            throw new IllegalOperationException("La cobertura no es válida");
        if (s.getCondiciones() == null || s.getCondiciones().isBlank())
            throw new IllegalOperationException("Las condiciones no son válidas");
        if (s.getPrecio() == null || s.getPrecio() < 0)
            throw new IllegalOperationException("El precio no es válido");
        if (s.getExpedicion() == null)
            throw new IllegalOperationException("Debe asociarse a una expedición");
    }
}
