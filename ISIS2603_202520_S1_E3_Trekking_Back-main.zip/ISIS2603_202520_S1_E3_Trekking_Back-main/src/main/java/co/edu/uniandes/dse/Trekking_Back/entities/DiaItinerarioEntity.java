package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import uk.co.jemos.podam.common.PodamExclude;
import jakarta.persistence.*;

@Data
@Entity
public class DiaItinerarioEntity extends BaseEntity{

    // Atributos basicos
    @Column(name = "numeroDia", nullable = true) 
    private Integer numeroDia;

    @Column(name = "nombreAlojamientoDia", nullable = true) 
    private String alojamiento;

    @Column(name = "actividadesDia", nullable = true) 
    private String actividades;

    @Column(name = "comidaDia", nullable = true) 
    private String comida;

    @Column(name = "descripcionDia", nullable = true) 
    private String descripcion;

    // Relacion con itinerario -> Multiples dias estan en un itinerario
    @ManyToOne(optional = false)
    @JoinColumn(name = "itinerario_id", nullable = false)
    @PodamExclude
    private ItinerarioEntity itinerario;
}