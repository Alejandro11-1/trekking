package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import uk.co.jemos.podam.common.PodamExclude;
import jakarta.persistence.*;

@Data
@Entity
public class SeguridadEntity extends BaseEntity {
    
    // Atributos basicos
    @Column(name = "nombreSeguidad", nullable = true) 
    private String nombre;

    @Column(name = "coberturaSeguridad", nullable = true) 
    private String cobertura;

    @Column(name = "condicionesSeguridad", nullable = true) 
    private String condiciones;

    @Column(name = "precioSeguridad", nullable = true) 
    private Long precio;

    @OneToOne(mappedBy = "seguridad")
    @PodamExclude
    private ExpedicionEntity expedicion;
}
