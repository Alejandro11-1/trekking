package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import co.edu.uniandes.dse.Trekking_Back.repositories.MapaRepository;

@Service
public class MapaService {
    @Autowired
    private MapaRepository mapaRepository;

    public MapaEntity crearMapa(MapaEntity mapa) {
        return mapaRepository.save(mapa);
    }

    public MapaEntity obtenerMapa(Long id) {
        return mapaRepository.findById(id).orElse(null);
    }

    public List<MapaEntity> obtenerTodosLosMapas() {
        return mapaRepository.findAll();
    }

    public MapaEntity actualizarMapa(Long id, MapaEntity detalles) {
        return mapaRepository.findById(id).map(mapa -> {
            mapa.setRuta(detalles.getRuta());
            mapa.setCoordenadasInicio(detalles.getCoordenadasInicio());
            mapa.setCoordenadasFin(detalles.getCoordenadasFin());
            return mapaRepository.save(mapa);
        }).orElse(null);
    }

    public void eliminarMapa(Long id) {
        mapaRepository.deleteById(id);
    }

    public List<MapaEntity> buscarPorRuta(String ruta) {
        return mapaRepository.findByRuta(ruta);
    }
}
