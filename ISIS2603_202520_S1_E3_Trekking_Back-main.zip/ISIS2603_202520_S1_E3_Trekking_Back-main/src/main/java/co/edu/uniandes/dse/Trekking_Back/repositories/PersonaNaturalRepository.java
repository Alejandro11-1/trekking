package co.edu.uniandes.dse.Trekking_Back.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import java.util.List;
import java.util.Optional;

@Repository
public interface PersonaNaturalRepository extends JpaRepository<PersonaNaturalEntity, Long> {
    Optional<PersonaNaturalEntity> findByIdCedula(String idCedula);
    List<PersonaNaturalEntity> findByNombre(String nombre);
    List<PersonaNaturalEntity> findByApellido(String apellido);
    Optional<PersonaNaturalEntity> findByFotoId(Long imagenId);
}