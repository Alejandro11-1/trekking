package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.DiaItinerarioRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ExpedicionRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ItinerarioRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItinerarioService {

    private static final String ERROR1 = "Expedición no válida";
    private static final String ERROR2 = "ITINERARIO_NOT_FOUND";

    @Autowired
    ItinerarioRepository itinerarioRepository;

    @Autowired
    ExpedicionRepository expedicionRepository;

    @Autowired
    DiaItinerarioRepository diaItinerarioRepository;

    @Transactional
    public ItinerarioEntity createItinerario(ItinerarioEntity itinerarioEntity) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de creación del itinerario");

        if (itinerarioEntity.getExpedicion() == null)
            throw new IllegalOperationException(ERROR1);

        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findById(itinerarioEntity.getExpedicion().getId());
        if (expedicionEntity.isEmpty())
            throw new IllegalOperationException(ERROR1);

        itinerarioEntity.setExpedicion(expedicionEntity.get());
        ItinerarioEntity savedItinerario = itinerarioRepository.save(itinerarioEntity);
        if (itinerarioEntity.getDias() != null) {
            for (DiaItinerarioEntity dia : itinerarioEntity.getDias()) {
                dia.setItinerario(savedItinerario);
                diaItinerarioRepository.save(dia);
            }
        }

        log.info("Termina proceso de creación del itinerario");
        return savedItinerario;
    }

    @Transactional
    public List<ItinerarioEntity> getItinerarios() {
        log.info("Inicia proceso de consultar todos los itinerarios");
        return itinerarioRepository.findAll();
    }

    @Transactional
    public ItinerarioEntity getItinerario(Long itinerarioId) throws EntityNotFoundException {
        log.info("Inicia proceso de consultar el itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException(ERROR2);
        log.info("Termina proceso de consultar el itinerario con id = {0}", itinerarioId);
        return itinerarioEntity.get();
    }

    @Transactional
    public ItinerarioEntity updateItinerario(Long itinerarioId, ItinerarioEntity itinerario)
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de actualizar el itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException(ERROR2);

        if (itinerario.getExpedicion() == null)
            throw new IllegalOperationException(ERROR1);

        Optional<ExpedicionEntity> expedicionEntity = expedicionRepository.findById(itinerario.getExpedicion().getId());
        if (expedicionEntity.isEmpty())
            throw new IllegalOperationException(ERROR1);

        itinerario.setId(itinerarioId);
        itinerario.setExpedicion(expedicionEntity.get());

        if (itinerario.getDias() != null) {
            List<DiaItinerarioEntity> existingDias = diaItinerarioRepository.findByItinerario(itinerarioEntity.get());
            for (DiaItinerarioEntity dia : existingDias) {
                diaItinerarioRepository.deleteById(dia.getId());
            }

            for (DiaItinerarioEntity dia : itinerario.getDias()) {
                dia.setItinerario(itinerario);
                diaItinerarioRepository.save(dia);
            }
        }

        log.info("Termina proceso de actualizar el itinerario con id = {0}", itinerarioId);
        return itinerarioRepository.save(itinerario);
    }

    @Transactional
    public void deleteItinerario(Long itinerarioId) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de borrar el itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException(ERROR2);

        List<DiaItinerarioEntity> dias = diaItinerarioRepository.findByItinerario(itinerarioEntity.get());

        if (!dias.isEmpty())
            throw new IllegalOperationException("No se puede eliminar el itinerario porque tiene días asociados");

        itinerarioRepository.deleteById(itinerarioId);
        log.info("Termina proceso de borrar el itinerario con id = {0}", itinerarioId);
    }
}