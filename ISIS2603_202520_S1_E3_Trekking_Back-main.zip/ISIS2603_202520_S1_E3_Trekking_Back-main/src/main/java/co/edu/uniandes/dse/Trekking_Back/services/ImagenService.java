package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.ClienteRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ExpedicionRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ImagenRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.PersonaJuridicaRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.PersonaNaturalRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ImagenService {

    @Autowired
    ImagenRepository imagenRepository;

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    ExpedicionRepository expedicionRepository;

    @Autowired
    PersonaNaturalRepository personaNaturalRepository;

    @Autowired
    PersonaJuridicaRepository personaJuridicaRepository;

    @Transactional
    public ImagenEntity createImagen(ImagenEntity imagenEntity) throws IllegalOperationException {
        log.info("Inicia proceso de creación de la imagen");

        if (imagenEntity.getUrl() == null || imagenEntity.getUrl().isEmpty())
            throw new IllegalOperationException("La URL no puede ser nula o vacía");

        Optional<ImagenEntity> imagenByUrl = imagenRepository.findByUrl(imagenEntity.getUrl());
        if (imagenByUrl.isPresent())
            throw new IllegalOperationException("Ya existe una imagen con esa URL");

        log.info("Termina proceso de creación de la imagen");
        return imagenRepository.save(imagenEntity);
    }

    @Transactional
    public List<ImagenEntity> getImagenes() {
        log.info("Inicia proceso de consultar todas las imágenes");
        return imagenRepository.findAll();
    }

    @Transactional
    public ImagenEntity getImagen(Long imagenId) throws EntityNotFoundException {
        log.info("Inicia proceso de consultar la imagen con id = {0}", imagenId);
        Optional<ImagenEntity> imagenEntity = imagenRepository.findById(imagenId);
        if (imagenEntity.isEmpty())
            throw new EntityNotFoundException("No se encontró la imagen con el id proporcionado");
        log.info("Termina proceso de consultar la imagen con id = {0}", imagenId);
        return imagenEntity.get();
    }

    @Transactional
    public ImagenEntity updateImagen(Long imagenId, ImagenEntity imagen) 
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de actualizar la imagen con id = {0}", imagenId);
        Optional<ImagenEntity> imagenEntity = imagenRepository.findById(imagenId);
        if (imagenEntity.isEmpty())
            throw new EntityNotFoundException("No se pudo actualizar ya que no se encontró la imagen con el id proporcionado");

        if (imagen.getUrl() == null || imagen.getUrl().isEmpty())
            throw new IllegalOperationException("La URL no puede ser nula o vacía");

        Optional<ImagenEntity> imagenByUrl = imagenRepository.findByUrl(imagen.getUrl());
        if (imagenByUrl.isPresent() && !imagenByUrl.get().getId().equals(imagenId))
            throw new IllegalOperationException("Ya existe una imagen con esa URL");

        imagen.setId(imagenId);
        log.info("Termina proceso de actualizar la imagen con id = {0}", imagenId);
        return imagenRepository.save(imagen);
    }

    @Transactional
    public void deleteImagen(Long imagenId) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de borrar la imagen con id = {0}", imagenId);
        Optional<ImagenEntity> imagenEntity = imagenRepository.findById(imagenId);
        if (imagenEntity.isEmpty())
            throw new EntityNotFoundException("No se pudo eliminar ya que no se encontró la imagen con el id proporcionado");

        // Verificar si la imagen está siendo utilizada por alguna entidad
        if (clienteRepository.findByImagenId(imagenId).isPresent())
            throw new IllegalOperationException("No se puede eliminar la imagen porque está siendo utilizada por un cliente");
        if (personaNaturalRepository.findByFotoId(imagenId).isPresent())
            throw new IllegalOperationException("No se puede eliminar la imagen porque está siendo utilizada por una persona natural");

        if (personaJuridicaRepository.findByLogoId(imagenId).isPresent())
            throw new IllegalOperationException("No se puede eliminar la imagen porque está siendo utilizada por una persona jurídica");

        imagenRepository.deleteById(imagenId);
        log.info("Termina proceso de borrar la imagen con id = {0}", imagenId);
    }
}