package co.edu.uniandes.dse.Trekking_Back.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;

@Repository
public interface MapaRepository extends JpaRepository<MapaEntity, Long> {
 List<MapaEntity> findByRuta(String ruta);
    List<MapaEntity> findByCoordenadasInicio(String coordenadasInicio);
    List<MapaEntity> findByCoordenadasFin(String coordenadasFin);
    Optional<MapaEntity> findByCoordenadasInicioAndCoordenadasFin(String coordenadasInicio, String coordenadasFin);
}

