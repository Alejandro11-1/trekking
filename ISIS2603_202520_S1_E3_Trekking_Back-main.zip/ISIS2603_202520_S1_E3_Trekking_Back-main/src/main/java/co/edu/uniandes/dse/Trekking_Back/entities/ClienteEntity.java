package co.edu.uniandes.dse.Trekking_Back.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
import uk.co.jemos.podam.common.PodamExclude;

@Data
@Entity
public class ClienteEntity extends BaseEntity{

    // Atributos basicos
    @Column(name = "nombreCliente", nullable = true) 
    private String nombre;

    @Column(name = "correoCliente", nullable = true) 
    private String correo;

    @Column(name = "contraseniaCliente", nullable = true) 
    private String contrasena;

    @Column(name = "cedulaCliente", nullable = true) 
    private String idCedula;

    // Atributos con otras relaciones

    // Relacion unica con imagen -> Un cliente tiene una unica imagen
    @OneToOne(cascade = CascadeType.ALL)
    @PodamExclude
    @JoinColumn(name = "imagen_id", unique = true)
    private ImagenEntity imagen;
}