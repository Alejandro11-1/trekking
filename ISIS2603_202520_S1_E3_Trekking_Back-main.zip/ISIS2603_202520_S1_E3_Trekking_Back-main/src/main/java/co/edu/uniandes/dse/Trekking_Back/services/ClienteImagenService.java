package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.ClienteEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.ClienteRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ImagenRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ClienteImagenService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ImagenRepository imagenRepository;

    @Transactional
    public ImagenEntity addImagen(Long clienteId, Long imagenId) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de asociarle una imagen al cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        Optional<ImagenEntity> imagenEntity = imagenRepository.findById(imagenId);

        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("El cliente esta vacio");

        if (imagenEntity.isEmpty())
            throw new EntityNotFoundException("La imagen no existe");

        if (clienteEntity.get().getImagen() != null) {
            throw new IllegalOperationException("El cliente ya tiene una imagen asociada");
        }

        Optional<ClienteEntity> clienteConImagen = clienteRepository.findByImagenId(imagenId);
        if (clienteConImagen.isPresent()) {
            throw new IllegalOperationException("La imagen ya está asociada a otro cliente");
        }

        clienteEntity.get().setImagen(imagenEntity.get());
        log.info("Termina proceso de asociarle una imagen al cliente con id = {0}", clienteId);
        return imagenEntity.get();
    }


    @Transactional
    public ImagenEntity getImagen(Long clienteId) throws EntityNotFoundException {
        log.info("Inicia proceso de consultar la imagen del cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("No se puede conseguir la imagen ya que el cliente no existe");

        ImagenEntity imagenEntity = clienteEntity.get().getImagen();
        if (imagenEntity == null)
            throw new EntityNotFoundException("El cliente no tiene una imagen asociada");

        log.info("Termina proceso de consultar la imagen del cliente con id = {0}", clienteId);
        return imagenEntity;
    }
     @Transactional
    public ImagenEntity replaceImagen(Long clienteId, Long imagenId) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de reemplazar la imagen del cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        Optional<ImagenEntity> imagenEntity = imagenRepository.findById(imagenId);

        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("No se puede reemplazar la imagen ya que el cliente no existe");

        if (imagenEntity.isEmpty())
            throw new EntityNotFoundException("La imagen no existe");

        Optional<ClienteEntity> clienteConImagen = clienteRepository.findByImagenId(imagenId);
        if (clienteConImagen.isPresent() && !clienteConImagen.get().getId().equals(clienteId)) {
            throw new IllegalOperationException("La imagen ya está asociada a otro cliente");
        }

        clienteEntity.get().setImagen(imagenEntity.get());
        log.info("Termina proceso de reemplazar la imagen del cliente con id = {0}", clienteId);
        return imagenEntity.get();
    }

    @Transactional
    public void removeImagen(Long clienteId) throws EntityNotFoundException {
        log.info("Inicia proceso de borrar la imagen del cliente con id = {0}", clienteId);
        Optional<ClienteEntity> clienteEntity = clienteRepository.findById(clienteId);
        if (clienteEntity.isEmpty())
            throw new EntityNotFoundException("No se puede eliminar la imagen ya que el cliente no existe");

        ImagenEntity imagenEntity = clienteEntity.get().getImagen();
        if (imagenEntity == null)
            throw new EntityNotFoundException("El cliente no tiene una imagen asociada");

        clienteEntity.get().setImagen(null);
        log.info("Termina proceso de borrar la imagen del cliente con id = {0}", clienteId);
    }
}