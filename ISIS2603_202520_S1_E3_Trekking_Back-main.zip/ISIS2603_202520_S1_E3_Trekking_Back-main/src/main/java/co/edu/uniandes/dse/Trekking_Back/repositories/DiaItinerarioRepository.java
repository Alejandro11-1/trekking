package co.edu.uniandes.dse.Trekking_Back.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import java.util.List;

@Repository
public interface DiaItinerarioRepository extends JpaRepository<DiaItinerarioEntity, Long>{
    List<DiaItinerarioEntity> findByDescripcion(String descripcion);
    List<DiaItinerarioEntity> findByItinerario(ItinerarioEntity itinerario);
}