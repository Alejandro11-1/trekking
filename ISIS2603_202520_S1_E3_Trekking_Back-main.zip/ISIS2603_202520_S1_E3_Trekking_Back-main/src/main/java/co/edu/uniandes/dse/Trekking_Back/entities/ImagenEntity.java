package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import jakarta.persistence.*;

@Entity
@Data
public class ImagenEntity extends BaseEntity {

    // Atributos basicos
    @Column(name = "urlImagen", nullable = true) 
    private String url;

    @Column(name = "idUnicoImagen", nullable = true) 
    private String idImagen;
}