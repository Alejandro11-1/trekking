package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.PersonaNaturalRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PersonaNaturalService {

    private static final String ERROR1 = "La persona natural no existe";

    @Autowired
    private PersonaNaturalRepository personaNaturalRepository;

    @Transactional
    public PersonaNaturalEntity crearPersonaNatural(PersonaNaturalEntity persona) throws IllegalOperationException {
        log.info("Inicia creacion de persona natural");
        if (persona.getNombre() == null || persona.getNombre().isEmpty())
            throw new IllegalOperationException("El nombre no es valido");
        if (persona.getApellido() == null || persona.getApellido().isEmpty())
            throw new IllegalOperationException("El apellido no es valido");
        if (persona.getIdCedula() == null || persona.getIdCedula().isEmpty())
            throw new IllegalOperationException("La cedula no puede estar vacia");

        if (personaNaturalRepository.findByIdCedula(persona.getIdCedula()).isPresent())
            throw new IllegalOperationException("Ya existe una persona con la misma cedula");

        return personaNaturalRepository.save(persona);
    }

    @Transactional
    public PersonaNaturalEntity getPersonaNatural(Long id) throws EntityNotFoundException {
        log.info("Consulta persona natural id={}", id);
        return personaNaturalRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(ERROR1));
    }

    @Transactional
    public List<PersonaNaturalEntity> getPersonasNaturales() {
        log.info("Consulta todas las personas naturales");
        return personaNaturalRepository.findAll();
    }

    @Transactional
    public PersonaNaturalEntity getPorCedula(String cedula) throws EntityNotFoundException, IllegalOperationException {
        log.info("Consulta persona natural por cedula={}", cedula);
        if (cedula == null || cedula.isEmpty())
            throw new IllegalOperationException("Debe indicar una cedula");
        return personaNaturalRepository.findByIdCedula(cedula)
                .orElseThrow(() -> new EntityNotFoundException(ERROR1));
    }

    @Transactional
    public List<PersonaNaturalEntity> getPorNombre(String nombre) throws IllegalOperationException {
        log.info("Consulta personas naturales por nombre={}", nombre);
        if (nombre == null || nombre.isEmpty())
            throw new IllegalOperationException("Debe indicar un nombre");
        return personaNaturalRepository.findByNombre(nombre);
    }

    @Transactional
    public List<PersonaNaturalEntity> getPorApellido(String apellido) throws IllegalOperationException {
        log.info("Consulta personas naturales por apellido={}", apellido);
        if (apellido == null || apellido.isEmpty())
            throw new IllegalOperationException("Debe indicar un apellido");
        return personaNaturalRepository.findByApellido(apellido);
    }

    @Transactional
    public PersonaNaturalEntity updatePersonaNatural(Long id, PersonaNaturalEntity persona)
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Actualiza persona natural id={}", id);
        if (!personaNaturalRepository.existsById(id))
            throw new EntityNotFoundException(ERROR1);

        if (persona.getNombre() == null || persona.getNombre().isEmpty())
            throw new IllegalOperationException("El nombre no es valido");
        if (persona.getApellido() == null || persona.getApellido().isEmpty())
            throw new IllegalOperationException("El apellido no es valido");
        if (persona.getIdCedula() == null || persona.getIdCedula().isEmpty())
            throw new IllegalOperationException("La cedula no puede estar vacia");

        // Unicidad de cédula
        Optional<PersonaNaturalEntity> clash = personaNaturalRepository.findByIdCedula(persona.getIdCedula());
        if (clash.isPresent() && !clash.get().getId().equals(id)) {
            throw new IllegalOperationException("Ya existe otra persona con la misma cedula");
        }

        persona.setId(id);
        return personaNaturalRepository.save(persona);
    }

    @Transactional
    public void deletePersonaNatural(Long id) throws EntityNotFoundException {
        log.info("Elimina persona natural id={}", id);
        if (!personaNaturalRepository.existsById(id))
            throw new EntityNotFoundException(ERROR1);
        personaNaturalRepository.deleteById(id);
    }
}

