package co.edu.uniandes.dse.Trekking_Back.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.uniandes.dse.Trekking_Back.entities.PersonaJuridicaEntity;
import java.util.Optional;

@Repository
public interface PersonaJuridicaRepository extends JpaRepository<PersonaJuridicaEntity, Long> {
    Optional<PersonaJuridicaEntity> findByNombreEmpresa(String nombreEmpresa);
    Optional<PersonaJuridicaEntity> findByLogoId(Long imagenId);
}

