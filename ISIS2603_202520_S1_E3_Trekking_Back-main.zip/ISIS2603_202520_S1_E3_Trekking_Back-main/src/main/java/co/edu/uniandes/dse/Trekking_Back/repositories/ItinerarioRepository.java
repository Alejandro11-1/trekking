package co.edu.uniandes.dse.Trekking_Back.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import java.util.List;

@Repository
public interface ItinerarioRepository extends JpaRepository<ItinerarioEntity, Long> {
    List<ItinerarioEntity> findByNombre(String nombre);
    List<ItinerarioEntity> findByExpedicion(ExpedicionEntity expedicion);
}
