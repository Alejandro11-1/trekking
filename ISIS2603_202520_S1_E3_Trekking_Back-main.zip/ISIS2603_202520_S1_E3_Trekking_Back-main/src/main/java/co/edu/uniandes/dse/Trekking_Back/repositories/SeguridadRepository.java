package co.edu.uniandes.dse.Trekking_Back.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;

@Repository
public interface SeguridadRepository extends JpaRepository<SeguridadEntity, Long> {

    List<SeguridadEntity> findByNombreContainingIgnoreCase(String nombre);

    List<SeguridadEntity> findByCoberturaContainingIgnoreCase(String cobertura);

    List<SeguridadEntity> findByCondicionesContainingIgnoreCase(String condiciones);

    List<SeguridadEntity> findByPrecioBetween(Long min, Long max);

    List<SeguridadEntity> findByExpedicion(ExpedicionEntity expedicion);

    List<SeguridadEntity> findByExpedicionId(Long expedicionId);
}

