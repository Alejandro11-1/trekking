package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.DiaItinerarioRepository;
import co.edu.uniandes.dse.Trekking_Back.repositories.ItinerarioRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItinerarioDiaItinerarioService {

    @Autowired
    private ItinerarioRepository itinerarioRepository;

    @Autowired
    private DiaItinerarioRepository diaItinerarioRepository;
    @Transactional
    public DiaItinerarioEntity addDiaItinerario(Long itinerarioId, Long diaItinerarioId) throws EntityNotFoundException {
        log.info("Inicia proceso de asociar un día de itinerario al itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        Optional<DiaItinerarioEntity> diaItinerarioEntity = diaItinerarioRepository.findById(diaItinerarioId);

        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException("El itinerario con el id dado no existe");

        if (diaItinerarioEntity.isEmpty())
            throw new EntityNotFoundException("El día de itinerario con el id dado no existe");

        diaItinerarioEntity.get().setItinerario(itinerarioEntity.get());
        log.info("Termina proceso de asociar un día de itinerario al itinerario con id = {0}", itinerarioId);
        return diaItinerarioEntity.get();
    }
    @Transactional
    public List<DiaItinerarioEntity> getDiasItinerario(Long itinerarioId) throws EntityNotFoundException {
        log.info("Inicia proceso de consultar todos los días de itinerario del itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException("No se puede obtener ya que el id del itinerario no existe");

        log.info("Termina proceso de consultar todos los días de itinerario del itinerario con id = {0}", itinerarioId);
        return itinerarioEntity.get().getDias();
    }
    @Transactional
    public DiaItinerarioEntity getDiaItinerario(Long itinerarioId, Long diaItinerarioId) throws EntityNotFoundException, IllegalOperationException {
        log.info("Inicia proceso de consultar el día de itinerario con id = {0} del itinerario con id = " + itinerarioId, diaItinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        Optional<DiaItinerarioEntity> diaItinerarioEntity = diaItinerarioRepository.findById(diaItinerarioId);

        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException( "No se puede obtener el itinerario ya que el id no existe");

        if (diaItinerarioEntity.isEmpty())
            throw new EntityNotFoundException("El día de itinerario no existe");

        log.info("Termina proceso de consultar el día de itinerario con id = {0} del itinerario con id = " + itinerarioId, diaItinerarioId);
        if (!diaItinerarioEntity.get().getItinerario().getId().equals(itinerarioId))
            throw new IllegalOperationException("El día de itinerario no está asociado al itinerario");

        return diaItinerarioEntity.get();
    }

    @Transactional
    public List<DiaItinerarioEntity> replaceDiasItinerario(Long itinerarioId, List<DiaItinerarioEntity> dias) throws EntityNotFoundException {
        log.info("Inicia proceso de reemplazar los días de itinerario asociados al itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException("El itinerario no existe");

        for (DiaItinerarioEntity dia : dias) {
            Optional<DiaItinerarioEntity> diaItinerarioEntity = diaItinerarioRepository.findById(dia.getId());
            if (diaItinerarioEntity.isEmpty())
                throw new EntityNotFoundException("No se puede actualizar ya que el día de itinerario con id " + dia.getId() + " no existe");
            diaItinerarioEntity.get().setItinerario(itinerarioEntity.get());
        }

        log.info("Finaliza proceso de reemplazar los días de itinerario asociados al itinerario con id = {0}", itinerarioId);
        itinerarioEntity.get().setDias(dias);
        return itinerarioEntity.get().getDias();
    }
    @Transactional
    public void removeDiaItinerario(Long itinerarioId, Long diaItinerarioId) throws EntityNotFoundException {
        log.info("Inicia proceso de borrar un día de itinerario del itinerario con id = {0}", itinerarioId);
        Optional<ItinerarioEntity> itinerarioEntity = itinerarioRepository.findById(itinerarioId);
        if (itinerarioEntity.isEmpty())
            throw new EntityNotFoundException("No se puede eliminar ya que el itinerario no existe");

        Optional<DiaItinerarioEntity> diaItinerarioEntity = diaItinerarioRepository.findById(diaItinerarioId);
        if (diaItinerarioEntity.isEmpty())
            throw new EntityNotFoundException("No se puede eliminar ya que el día de itinerario no existe");

        diaItinerarioEntity.get().setItinerario(null);
        itinerarioEntity.get().getDias().remove(diaItinerarioEntity.get());
        log.info("Finaliza proceso de borrar un día de itinerario del itinerario con id = {0}", itinerarioId);
    }
}