package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import uk.co.jemos.podam.common.PodamExclude;
import jakarta.persistence.*;

@Data
@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_oferente", discriminatorType = DiscriminatorType.STRING, length = 20)
public abstract class OferenteEntity extends BaseEntity{
    
    // Atributos básicos
    @Column(name = "nivelExperiencia", nullable = true)
    private Float nivelexperiencia;   // ← antes era String

    // Relación única con expedición
    @OneToOne(mappedBy = "oferente", optional = false)
    @PodamExclude
    private ExpedicionEntity expedicion;
}