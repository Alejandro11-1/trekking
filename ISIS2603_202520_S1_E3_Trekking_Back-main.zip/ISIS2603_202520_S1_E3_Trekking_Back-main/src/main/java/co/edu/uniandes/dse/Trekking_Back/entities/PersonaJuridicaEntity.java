package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import lombok.EqualsAndHashCode;
import uk.co.jemos.podam.common.PodamExclude;
import jakarta.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@DiscriminatorValue("PERSONA_JURIDICA")
public class PersonaJuridicaEntity extends OferenteEntity {
    // Clase hija de Oferente

    // Atributos basicos
    @Column(name = "nombre_empresa", nullable = true) 
    @PodamExclude
    private String nombreEmpresa;

    // Relacion con imagen -> 1 persona juridica tiene solamente 1 imagen
    @OneToOne(cascade = CascadeType.ALL)
    @PodamExclude
    @JoinColumn(name = "logo_id")
    private ImagenEntity logo;
}
