package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import uk.co.jemos.podam.common.PodamExclude;
import jakarta.persistence.*;
import java.util.List;

@Data
@Entity
public class ExpedicionEntity extends BaseEntity{
    
    // Atributos basicos
    @Column(name = "nombreExpedicion", nullable = true) 
    private String nombre;

    @Column(name = "fechaInicio", nullable = true) 
    private String fechaInicio;

    @Column(name = "fechaFin", nullable = true) 
    private String fechaFin;

    @Column(name = "horaSalida", nullable = true) 
    private String horaSalida;

    @Column(name = "horaLlegada", nullable = true) 
    private String horaLlegada;

    @Column(name = "lugarSalida", nullable = true) 
    private String lugarSalida;

    @Column(name = "lugarLlegada", nullable = true) 
    private String lugarLlegada;

    @Column(name = "descripcion", nullable = true) 
    private String descripcion;

    @Column(name = "duracion", nullable = true) 
    private int duracion;

    @Column(name = "recomendaciones", nullable = true) 
    private String recomendaciones;

    @Column(name = "costoExpedicion", nullable = true) 
    private Long costo;

    // Atributos con otras relaciones

    // Relacion unica con oferente -> Una expedicion tiene 1 Persona Juridica o 1 Persona Natural
    @OneToOne(optional = false, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "oferente_id", nullable = false, unique = true)
    @PodamExclude
    private OferenteEntity oferente;

    // Relacion unica con mapa -> Una expedicion tiene 1 mapa
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @PodamExclude
    @JoinColumn(name = "mapa_id", unique = true, nullable = false)
    private MapaEntity mapa;

    // Relacion con Seguidad -> Una expedicion tiene 1 opcion de seguidad
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, optional = false)
    @JoinColumn(name = "seguridad_id", nullable = false, unique = true)
    @PodamExclude
    private SeguridadEntity seguridad;

    // Relacion con itinerario -> Una expedicion tiene un unico itinerario
    @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
    @PodamExclude
    @JoinColumn(name = "itinerario_id")
    private ItinerarioEntity itinerario;

    // Relacion con imagen -> Una expedicion tiene multiples imagenes asociadas
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @PodamExclude
    @JoinColumn(name = "expedicion_id")
    private List<ImagenEntity> galeria;
}
