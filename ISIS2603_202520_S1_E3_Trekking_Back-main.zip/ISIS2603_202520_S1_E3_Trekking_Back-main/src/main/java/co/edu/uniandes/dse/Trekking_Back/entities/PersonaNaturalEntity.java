package co.edu.uniandes.dse.Trekking_Back.entities;

import lombok.Data;
import lombok.EqualsAndHashCode;
import uk.co.jemos.podam.common.PodamExclude;
import jakarta.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@DiscriminatorValue("PERSONA_NATURAL")
public class PersonaNaturalEntity extends OferenteEntity {
    // Clase hija de Oferente

    // Atributos basicos
    @Column(name = "nombre", nullable = true)
    private String nombre;

    @Column(name = "apellido", nullable = true)
    private String apellido;

    @Column(name = "id_cedula", nullable = true)
    private String idCedula;

    // Relacion con imagen -> 1 persona natural tiene solamente 1 imagen
    @OneToOne(cascade = CascadeType.ALL)
    @PodamExclude
    @JoinColumn(name = "foto_id")
    private ImagenEntity foto;
}
