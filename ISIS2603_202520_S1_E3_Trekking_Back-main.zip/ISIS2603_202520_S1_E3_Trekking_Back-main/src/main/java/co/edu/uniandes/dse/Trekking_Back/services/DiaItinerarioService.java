package co.edu.uniandes.dse.Trekking_Back.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import co.edu.uniandes.dse.Trekking_Back.repositories.DiaItinerarioRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DiaItinerarioService {

    @Autowired
    private DiaItinerarioRepository diaItinerarioRepository;

    @Transactional
    public DiaItinerarioEntity crearDia(DiaItinerarioEntity dia) throws IllegalOperationException {
        log.info("Inicia creación de día de itinerario");
        if (dia.getNumeroDia() == null || dia.getNumeroDia() <= 0)
            throw new IllegalOperationException("El número de día no es válido");
        if (dia.getItinerario() == null)
            throw new IllegalOperationException("El día debe pertenecer a un itinerario");
        return diaItinerarioRepository.save(dia);
    }

    @Transactional
    public DiaItinerarioEntity getDiaPorId(Long id) throws EntityNotFoundException {
        log.info("Consulta día de itinerario id={}", id);
        return diaItinerarioRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("El día de itinerario con el id dado no existe"));
    }

    @Transactional
    public List<DiaItinerarioEntity> getDiasPorDescripcion(String descripcion) {
        log.info("Consulta días por descripción={}", descripcion);
        return diaItinerarioRepository.findByDescripcion(descripcion);
    }

    @Transactional
    public List<DiaItinerarioEntity> getDiasPorItinerario(ItinerarioEntity itinerario)
            throws IllegalOperationException {
        if (itinerario == null)
            throw new IllegalOperationException("Debe indicar un itinerario");
        return diaItinerarioRepository.findByItinerario(itinerario);
    }

    @Transactional
    public DiaItinerarioEntity updateDia(Long id, DiaItinerarioEntity dia)
            throws EntityNotFoundException, IllegalOperationException {
        log.info("Actualiza día de itinerario id={}", id);
        if (!diaItinerarioRepository.existsById(id))
            throw new EntityNotFoundException("No se encuentra un itinerario con ese id");
        if (dia.getNumeroDia() == null || dia.getNumeroDia() <= 0)
            throw new IllegalOperationException("El número de día no es válido");
        if (dia.getItinerario() == null)
            throw new IllegalOperationException("El día debe pertenecer a un itinerario");

        dia.setId(id);
        return diaItinerarioRepository.save(dia);
    }

    @Transactional
    public void deleteDia(Long id) throws EntityNotFoundException {
        log.info("Elimina día de itinerario id={}", id);
        if (!diaItinerarioRepository.existsById(id))
            throw new EntityNotFoundException("No se puede eliminar ya que el dia con el id dado no existe");
        diaItinerarioRepository.deleteById(id);
    }
}

