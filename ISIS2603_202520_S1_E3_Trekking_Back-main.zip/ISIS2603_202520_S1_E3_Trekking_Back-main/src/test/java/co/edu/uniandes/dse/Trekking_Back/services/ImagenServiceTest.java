package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.ClienteEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaJuridicaEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(ImagenService.class)
class ImagenServiceTest {
    @Autowired
    private ImagenService imagenService;
    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();

    private List<ImagenEntity> imagenList = new ArrayList<>();

    @BeforeEach
    void setUp(){
        clearData();
        insertData();
    }
    
    private void clearData(){
        entityManager.getEntityManager().createQuery("delete from ClienteEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ExpedicionEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from PersonaNaturalEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from PersonaJuridicaEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
        imagenList.clear();
    }
    
    private void insertData(){
        for (int i = 0; i < 3; i++){
            ImagenEntity imagen = factory.manufacturePojo(ImagenEntity.class);
            imagen.setUrl("http://example.com/image" + i + ".jpg");
            entityManager.persist(imagen);
            imagenList.add(imagen);
        }
    }
    
    @Test
    void testCreateImagen() throws IllegalOperationException{
        ImagenEntity newImagen = factory.manufacturePojo(ImagenEntity.class);
        newImagen.setUrl("http://example.com/new-image.jpg");
        
        ImagenEntity resultado = imagenService.createImagen(newImagen);
        assertNotNull(resultado);

        ImagenEntity entity = entityManager.find(ImagenEntity.class, resultado.getId());
        assertEquals(newImagen.getUrl(), entity.getUrl());
        assertEquals(newImagen.getIdImagen(), entity.getIdImagen());
    }
    
    @Test
    void testCreateImagenWithDuplicateUrl() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity newImagen = factory.manufacturePojo(ImagenEntity.class);
            newImagen.setUrl(imagenList.get(0).getUrl());
            
            imagenService.createImagen(newImagen);
        });
    }
    
    @Test
    void testCreateImagenWithNullUrl() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity newImagen = factory.manufacturePojo(ImagenEntity.class);
            newImagen.setUrl(null);
            
            imagenService.createImagen(newImagen);
        });
    }

    @Test
    void testGetImagen() throws EntityNotFoundException {
        ImagenEntity entity = imagenList.get(0);
        ImagenEntity resultEntity = imagenService.getImagen(entity.getId());
        assertNotNull(resultEntity);
        assertEquals(entity.getId(), resultEntity.getId());
        assertEquals(entity.getUrl(), resultEntity.getUrl());
        assertEquals(entity.getIdImagen(), resultEntity.getIdImagen());
    }

    @Test
    void testGetImagenes() {
        List<ImagenEntity> list = imagenService.getImagenes();
        assertEquals(imagenList.size(), list.size());
        for (ImagenEntity entity : list) {
            boolean found = false;
            for (ImagenEntity storedEntity : imagenList) {
                if (entity.getId().equals(storedEntity.getId())) {
                    found = true;
                }
            }
            assertTrue(found);
        }
    }
    
    @Test
    void testGetInvalidImagen() {
        assertThrows(EntityNotFoundException.class, () -> imagenService.getImagen(0L));
    }

    @Test
    void testUpdateImagen() throws EntityNotFoundException, IllegalOperationException {
        ImagenEntity guardado = imagenList.get(0);
        ImagenEntity update = factory.manufacturePojo(ImagenEntity.class);
        update.setUrl("http://example.com/updated-image.jpg");

        ImagenEntity resultado = imagenService.updateImagen(guardado.getId(), update);
        assertEquals("http://example.com/updated-image.jpg", resultado.getUrl());
    }
    
    @Test
    void testUpdateImagenWithDuplicateUrl() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity guardado = imagenList.get(0);
            ImagenEntity update = factory.manufacturePojo(ImagenEntity.class);
            update.setUrl(imagenList.get(1).getUrl());
            
            imagenService.updateImagen(guardado.getId(), update);
        });
    }
    
    @Test
    void testDeleteImagen() throws EntityNotFoundException, IllegalOperationException {
        ImagenEntity entity = imagenList.get(1);
        imagenService.deleteImagen(entity.getId());
        ImagenEntity deleted = entityManager.find(ImagenEntity.class, entity.getId());
        assertNull(deleted);
    }
    
    @Test
    void testDeleteInvalidImagen() {
        assertThrows(EntityNotFoundException.class, () -> imagenService.deleteImagen(0L));
    }

    @Test
    void testDeleteImagenWithCliente() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity imagen = imagenList.get(0);
            ClienteEntity cliente = factory.manufacturePojo(ClienteEntity.class);
            cliente.setImagen(imagen);
            entityManager.persist(cliente);

            imagenService.deleteImagen(imagen.getId());
        });
    }
    @Test
    void testDeleteImagenWithPersonaNatural() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity imagen = imagenList.get(0);
            PersonaNaturalEntity personaNatural = factory.manufacturePojo(PersonaNaturalEntity.class);
            personaNatural.setFoto(imagen);
            entityManager.persist(personaNatural);
            
            imagenService.deleteImagen(imagen.getId());
        });
    }

    @Test
    void testDeleteImagenWithPersonaJuridica() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity imagen = imagenList.get(0);
            PersonaJuridicaEntity personaJuridica = factory.manufacturePojo(PersonaJuridicaEntity.class);
            personaJuridica.setLogo(imagen);
            entityManager.persist(personaJuridica);
            
            imagenService.deleteImagen(imagen.getId());
        });
    }
}