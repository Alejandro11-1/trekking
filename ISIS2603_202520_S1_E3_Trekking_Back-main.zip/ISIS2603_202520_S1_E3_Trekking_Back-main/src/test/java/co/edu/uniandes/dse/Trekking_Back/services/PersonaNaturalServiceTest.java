package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(PersonaNaturalService.class)
class PersonaNaturalServiceTest {

    @Autowired
    private PersonaNaturalService personaNaturalService;

    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();
    private List<PersonaNaturalEntity> lista = new ArrayList<>();

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        entityManager.getEntityManager().createQuery("delete from PersonaNaturalEntity").executeUpdate();
        lista.clear();
    }

    private void insertData() {
        for (int i = 0; i < 3; i++) {
            PersonaNaturalEntity entity = factory.manufacturePojo(PersonaNaturalEntity.class);
            entity.setIdCedula("CED" + i);
            if (entity.getNombre() == null || entity.getNombre().isBlank()) entity.setNombre("Nombre" + i);
            if (entity.getApellido() == null || entity.getApellido().isBlank()) entity.setApellido("Apellido" + i);
            entityManager.persist(entity);
            lista.add(entity);
        }
    }

    // Crear

    @Test
    void testCrearPersonaNatural() throws IllegalOperationException {
        PersonaNaturalEntity nueva = factory.manufacturePojo(PersonaNaturalEntity.class);
        nueva.setIdCedula("CED10");
        nueva.setNombre("Juan");
        nueva.setApellido("Pérez");

        PersonaNaturalEntity result = personaNaturalService.crearPersonaNatural(nueva);
        assertNotNull(result);

        PersonaNaturalEntity entity = entityManager.find(PersonaNaturalEntity.class, result.getId());
        assertEquals(result.getId(), entity.getId());
        assertEquals("Juan", entity.getNombre());
        assertEquals("Pérez", entity.getApellido());
        assertEquals("CED10", entity.getIdCedula());
    }

    @Test
    void testCrearPersonaNaturalCedulaDuplicada() {
        assertThrows(IllegalOperationException.class, () -> {
            PersonaNaturalEntity clash = factory.manufacturePojo(PersonaNaturalEntity.class);
            clash.setIdCedula(lista.get(0).getIdCedula()); // duplicada
            clash.setNombre("X");
            clash.setApellido("Y");
            personaNaturalService.crearPersonaNatural(clash);
        });
    }

    @Test
    void testCrearPersonaNaturalCamposInvalidos() {
        assertThrows(IllegalOperationException.class, () -> {
            PersonaNaturalEntity inval = factory.manufacturePojo(PersonaNaturalEntity.class);
            inval.setIdCedula(""); // inválido
            inval.setNombre("");   // inválido
            inval.setApellido(""); // inválido
            personaNaturalService.crearPersonaNatural(inval);
        });
    }

    // Consutar

    @Test
    void testGetPersonaNatural() throws EntityNotFoundException {
        PersonaNaturalEntity base = lista.get(0);
        PersonaNaturalEntity result = personaNaturalService.getPersonaNatural(base.getId());
        assertNotNull(result);
        assertEquals(base.getIdCedula(), result.getIdCedula());
    }

    @Test
    void testGetInvalidPersonaNatural() {
        assertThrows(EntityNotFoundException.class, () -> personaNaturalService.getPersonaNatural(0L));
    }

    @Test
    void testGetPersonasNaturales() {
        List<PersonaNaturalEntity> all = personaNaturalService.getPersonasNaturales();
        assertEquals(lista.size(), all.size());
    }

    @Test
    void testGetPorCedula() throws Exception {
        PersonaNaturalEntity base = lista.get(1);
        PersonaNaturalEntity found = personaNaturalService.getPorCedula(base.getIdCedula());
        assertEquals(base.getId(), found.getId());
    }

    @Test
    void testGetPorCedulaInvalida() {
        assertThrows(IllegalOperationException.class, () -> personaNaturalService.getPorCedula(""));
    }

    // Actualizar

    @Test
    void testUpdatePersonaNatural() throws Exception {
        PersonaNaturalEntity base = lista.get(0);

        PersonaNaturalEntity cambios = factory.manufacturePojo(PersonaNaturalEntity.class);
        cambios.setIdCedula("CED200");
        cambios.setNombre("NuevoNombre");
        cambios.setApellido("NuevoApellido");

        PersonaNaturalEntity actualizado = personaNaturalService.updatePersonaNatural(base.getId(), cambios);

        assertEquals(base.getId(), actualizado.getId());
        assertEquals("CED200", actualizado.getIdCedula());
        assertEquals("NuevoNombre", actualizado.getNombre());
        assertEquals("NuevoApellido", actualizado.getApellido());
    }

    @Test
    void testUpdatePersonaNaturalNoExiste() {
        assertThrows(EntityNotFoundException.class, () -> {
            PersonaNaturalEntity cambios = factory.manufacturePojo(PersonaNaturalEntity.class);
            cambios.setIdCedula("CED999");
            cambios.setNombre("X");
            cambios.setApellido("Y");
            personaNaturalService.updatePersonaNatural(999999L, cambios);
        });
    }

    @Test
    void testUpdatePersonaNaturalCedulaDuplicada() {
        PersonaNaturalEntity base = lista.get(0);
        assertThrows(IllegalOperationException.class, () -> {
            PersonaNaturalEntity cambios = factory.manufacturePojo(PersonaNaturalEntity.class);
            cambios.setIdCedula(lista.get(1).getIdCedula()); // duplicada
            cambios.setNombre("X");
            cambios.setApellido("Y");
            personaNaturalService.updatePersonaNatural(base.getId(), cambios);
        });
    }

    @Test
    void testDeletePersonaNatural() throws EntityNotFoundException {
        PersonaNaturalEntity base = lista.get(2);
        personaNaturalService.deletePersonaNatural(base.getId());
        assertThrows(EntityNotFoundException.class, () -> personaNaturalService.getPersonaNatural(base.getId()));
    }

    @Test
    void testDeletePersonaNaturalNoExiste() {
        assertThrows(EntityNotFoundException.class, () -> personaNaturalService.deletePersonaNatural(777777L));
    }

    @Test
    void personaNatural_creaYElimina_cascadaImagen() {
        PersonaNaturalEntity pn = factory.manufacturePojo(PersonaNaturalEntity.class);
        pn.setIdCedula("CED_IMG_1");
        // asegurar campos válidos:
        pn.setNombre("Ana"); pn.setApellido("Pérez");

        // imagen generada por Podam
        pn.setFoto(factory.manufacturePojo(co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity.class));

        pn = entityManager.persist(pn);
        entityManager.flush();

        Long fotoId = pn.getFoto().getId();
        assertNotNull(entityManager.find(
            co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity.class, fotoId));

        // eliminar PN y confirmar que la imagen se fue por cascade ALL
        entityManager.remove(pn);
        entityManager.flush();

        assertNull(entityManager.find(
            co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity.class, fotoId));
    }

}

