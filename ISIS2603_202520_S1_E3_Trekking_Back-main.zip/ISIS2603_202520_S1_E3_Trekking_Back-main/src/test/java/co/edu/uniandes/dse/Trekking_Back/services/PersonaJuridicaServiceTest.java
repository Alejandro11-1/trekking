package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;

import co.edu.uniandes.dse.Trekking_Back.entities.PersonaJuridicaEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;

@DataJpaTest
@Import(PersonaJuridicaService.class)
class PersonaJuridicaServiceTest {

    @Autowired
    private PersonaJuridicaService personaJuridicaService;

    @Autowired
    private TestEntityManager entityManager;

    private PersonaJuridicaEntity personaJuridica;

    @BeforeEach
    void setUp() {
        personaJuridica = new PersonaJuridicaEntity();
        personaJuridica.setNombreEmpresa("Empresa Trekking");
        personaJuridica.setNivelexperiencia(5f);
        // Id lo genera JPA
        entityManager.persist(personaJuridica);
    }

    @Test
    void testCreatePersonaJuridica() throws IllegalOperationException {
        PersonaJuridicaEntity entity = new PersonaJuridicaEntity();
        entity.setNombreEmpresa("Nueva Empresa");
        entity.setNivelexperiencia(2f);

        PersonaJuridicaEntity result = personaJuridicaService.crearPersonaJuridica(entity);

        assertNotNull(result.getId());
        assertEquals("Nueva Empresa", result.getNombreEmpresa());
    }

    @Test
    void testGetPersonaJuridica() throws EntityNotFoundException {
        PersonaJuridicaEntity result = personaJuridicaService.getPersonaJuridica(personaJuridica.getId());
        assertNotNull(result);
        assertEquals(personaJuridica.getNombreEmpresa(), result.getNombreEmpresa());
    }

    @Test
    void testGetPersonasJuridicas() {
        List<PersonaJuridicaEntity> list = personaJuridicaService.getPersonasJuridicas();
        assertFalse(list.isEmpty());
    }

    @Test
    void testDeletePersonaJuridica() throws EntityNotFoundException {
        Long id = personaJuridica.getId();
        personaJuridicaService.deletePersonaJuridica(id);
        Optional<PersonaJuridicaEntity> deleted = Optional.ofNullable(entityManager.find(PersonaJuridicaEntity.class, id));
        assertTrue(deleted.isEmpty());
    }
}