package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(ItinerarioService.class)
class ItinerarioServiceTest {

    @Autowired
    private ItinerarioService itinerarioService;

    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();

    private List<ItinerarioEntity> itinerarioList = new ArrayList<>();
    private List<ExpedicionEntity> expedicionList = new ArrayList<>();

    private List<ItinerarioEntity> itinerarios = new ArrayList<>();
    private List<DiaItinerarioEntity> dias = new ArrayList<>();

    // DICE QUE HAY ERROR PERO NO ASI QUE NO ELIMINAR PLIS
    private ItinerarioEntity i1, i2, i3;
    private ExpedicionEntity e1, e2, e3;

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        entityManager.getEntityManager().createQuery("delete from DiaItinerarioEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ItinerarioEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ExpedicionEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from SeguridadEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from MapaEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from PersonaNaturalEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
    }

    private PersonaNaturalEntity crearOferenteConFoto() {
        ImagenEntity img = factory.manufacturePojo(ImagenEntity.class);
        entityManager.persist(img);
    
        PersonaNaturalEntity oferente = factory.manufacturePojo(PersonaNaturalEntity.class);
        oferente.setFoto(img);
        entityManager.persist(oferente);
        return oferente;
    }
    
    private void setRequeridosExpedicion(ExpedicionEntity exp) {
        MapaEntity mapa = factory.manufacturePojo(MapaEntity.class);
        entityManager.persist(mapa);
    
        SeguridadEntity seg = factory.manufacturePojo(SeguridadEntity.class);
        entityManager.persist(seg);
    
        exp.setMapa(mapa);
        exp.setSeguridad(seg);
    }

    private void insertData() {
        // Limpia también las listas usadas por los tests
        itinerarioList.clear();
        expedicionList.clear();
    
        itinerarios.clear();
        dias.clear();
    
        for (int i = 0; i < 3; i++) {
            // --- EXPEDICIÓN COMPLETA (oferente con foto, mapa y seguridad) ---
            ExpedicionEntity exp = factory.manufacturePojo(ExpedicionEntity.class);
            exp.setOferente(crearOferenteConFoto());
            setRequeridosExpedicion(exp);
            entityManager.persist(exp);
            expedicionList.add(exp); // <- NECESARIO para tests que usan expedicionList.get(...)
    
            // --- ITINERARIO LIGADO A LA EXPEDICIÓN ---
            ItinerarioEntity iti = factory.manufacturePojo(ItinerarioEntity.class);
            iti.setExpedicion(exp);
            if (iti.getDias() == null) iti.setDias(new ArrayList<>());
            entityManager.persist(iti);
    
            // Reglas para que los tests pasen:
            // i==0 -> con días (para testDeleteItinerarioWithDias)
            // i==1 -> sin días (para testDeleteItinerario)
            // i==2 -> como quieras; le ponemos 1 día.
            int nDias;
            if (i == 0) nDias = 2;   // con días
            else if (i == 1) nDias = 0; // sin días
            else nDias = 1;
    
            for (int d = 0; d < nDias; d++) {
                DiaItinerarioEntity dia = factory.manufacturePojo(DiaItinerarioEntity.class);
                dia.setItinerario(iti);
                entityManager.persist(dia);
    
                dias.add(dia);
                iti.getDias().add(dia);
            }
    
            // Guarda en ambas listas de apoyo
            itinerarios.add(iti);
            itinerarioList.add(iti); // <- NECESARIO para tests que usan itinerarioList.get(...)
    
            // referencias rápidas (no indispensables para tus tests actuales)
            if (i == 0) { i1 = iti; e1 = exp; }
            if (i == 1) { i2 = iti; e2 = exp; }
            if (i == 2) { i3 = iti; e3 = exp; }
        }
        entityManager.flush();
    }

    @Test
    void testCreateItinerario() throws EntityNotFoundException, IllegalOperationException {
        ItinerarioEntity newEntity = factory.manufacturePojo(ItinerarioEntity.class);
        newEntity.setExpedicion(expedicionList.get(0));
        ItinerarioEntity result = itinerarioService.createItinerario(newEntity);
        assertNotNull(result);
        
        ItinerarioEntity entity = entityManager.find(ItinerarioEntity.class, result.getId());
        assertEquals(newEntity.getId(), entity.getId());
        assertEquals(newEntity.getNombre(), entity.getNombre());
        assertEquals(newEntity.getExpedicion().getId(), entity.getExpedicion().getId());
    }

    @Test
    void testCreateItinerarioWithInvalidExpedicion() {
        assertThrows(IllegalOperationException.class, () -> {
            ItinerarioEntity newEntity = factory.manufacturePojo(ItinerarioEntity.class);
            ExpedicionEntity newExpedicionEntity = new ExpedicionEntity();
            newExpedicionEntity.setId(0L);
            newEntity.setExpedicion(newExpedicionEntity);
            itinerarioService.createItinerario(newEntity);
        });
    }

    @Test
    void testCreateItinerarioWithNullExpedicion() {
        assertThrows(IllegalOperationException.class, () -> {
            ItinerarioEntity newEntity = factory.manufacturePojo(ItinerarioEntity.class);
            newEntity.setExpedicion(null);
            itinerarioService.createItinerario(newEntity);
        });
    }

    @Test
    void testGetItinerarios() {
        List<ItinerarioEntity> list = itinerarioService.getItinerarios();
        assertEquals(itinerarioList.size(), list.size());
        
        for (ItinerarioEntity entity : list) {
            boolean found = false;
            for (ItinerarioEntity storedEntity : itinerarioList) {
                if (entity.getId().equals(storedEntity.getId())) {
                    found = true;
                }
            }
            assertTrue(found);
        }
    }

    @Test
    void testGetItinerario() throws EntityNotFoundException {
        ItinerarioEntity entity = itinerarioList.get(0);
        ItinerarioEntity resultEntity = itinerarioService.getItinerario(entity.getId());
        assertNotNull(resultEntity);
        assertEquals(entity.getId(), resultEntity.getId());
        assertEquals(entity.getNombre(), resultEntity.getNombre());
        assertEquals(entity.getExpedicion().getId(), resultEntity.getExpedicion().getId());
    }
    @Test
    void testGetInvalidItinerario() {
        assertThrows(EntityNotFoundException.class,()->{
            itinerarioService.getItinerario(0L);
        });
    }
    
    @Test
    void testUpdateItinerarioInvalid() {
        assertThrows(EntityNotFoundException.class, () -> {
            ItinerarioEntity pojoEntity = factory.manufacturePojo(ItinerarioEntity.class);
            pojoEntity.setId(0L);
            pojoEntity.setExpedicion(expedicionList.get(0));
            itinerarioService.updateItinerario(0L, pojoEntity);
        });
    }

    @Test
    void testUpdateItinerarioWithInvalidExpedicion() {
        assertThrows(IllegalOperationException.class, () -> {
            ItinerarioEntity entity = itinerarioList.get(0);
            ItinerarioEntity pojoEntity = factory.manufacturePojo(ItinerarioEntity.class);
            pojoEntity.setId(entity.getId());
            
            ExpedicionEntity invalidExpedicion = new ExpedicionEntity();
            invalidExpedicion.setId(0L);
            pojoEntity.setExpedicion(invalidExpedicion);
            
            itinerarioService.updateItinerario(entity.getId(), pojoEntity);
        });
    }


    @Test
    void testDeleteItinerario() throws EntityNotFoundException, IllegalOperationException {
        ItinerarioEntity entity = itinerarioList.get(1); // El segundo itinerario no tiene días asociados
        itinerarioService.deleteItinerario(entity.getId());
        ItinerarioEntity deleted = entityManager.find(ItinerarioEntity.class, entity.getId());
        assertNull(deleted);
    }

    @Test
    void testDeleteInvalidItinerario() {
        assertThrows(EntityNotFoundException.class, ()->{
            itinerarioService.deleteItinerario(0L);
        });
    }
    @Test
    void testDeleteItinerarioWithDias() {
        assertThrows(IllegalOperationException.class, () -> {
            ItinerarioEntity entity = itinerarioList.get(0); // El primer itinerario tiene días asociados
            itinerarioService.deleteItinerario(entity.getId());
        });
    }
}