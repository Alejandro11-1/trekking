package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(MapaService.class)
class MapaServiceTest {

    @Autowired
    private MapaService mapaService;

    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();

    private List<MapaEntity> mapaList = new ArrayList<>();

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        entityManager.getEntityManager().createQuery("delete from MapaEntity").executeUpdate();
        mapaList.clear();
    }

    private void insertData() {
        for (int i = 0; i < 3; i++) {
            MapaEntity mapa = factory.manufacturePojo(MapaEntity.class);
            mapa.setRuta("Ruta " + i);
            mapa.setCoordenadasInicio("Inicio " + i);
            mapa.setCoordenadasFin("Fin " + i);
            entityManager.persist(mapa);
            mapaList.add(mapa);
        }
    }

    @Test
    void testCrearMapa() {
        MapaEntity newMapa = factory.manufacturePojo(MapaEntity.class);
        newMapa.setRuta("Ruta Principal");
        newMapa.setCoordenadasInicio("Lat: 1.234, Lng: 5.678");
        newMapa.setCoordenadasFin("Lat: 9.876, Lng: 5.432");

        MapaEntity resultado = mapaService.crearMapa(newMapa);
        assertNotNull(resultado);

        MapaEntity entity = entityManager.find(MapaEntity.class, resultado.getId());
        assertEquals(newMapa.getRuta(), entity.getRuta());
        assertEquals(newMapa.getCoordenadasInicio(), entity.getCoordenadasInicio());
        assertEquals(newMapa.getCoordenadasFin(), entity.getCoordenadasFin());
    }

    @Test
    void testObtenerMapaExistente() {
        MapaEntity entity = mapaList.get(0);
        MapaEntity resultEntity = mapaService.obtenerMapa(entity.getId());
        assertNotNull(resultEntity);
        assertEquals(entity.getId(), resultEntity.getId());
        assertEquals(entity.getRuta(), resultEntity.getRuta());
        assertEquals(entity.getCoordenadasInicio(), resultEntity.getCoordenadasInicio());
        assertEquals(entity.getCoordenadasFin(), resultEntity.getCoordenadasFin());
    }

    @Test
    void testObtenerMapaInexistente() {
        MapaEntity resultEntity = mapaService.obtenerMapa(0L);
        assertNull(resultEntity);
    }

    @Test
    void testObtenerTodosLosMapas() {
        List<MapaEntity> list = mapaService.obtenerTodosLosMapas();
        assertEquals(mapaList.size(), list.size());
        for (MapaEntity entity : list) {
            boolean found = mapaList.stream().anyMatch(m -> m.getId().equals(entity.getId()));
            assertTrue(found);
        }
    }

    @Test
    void testActualizarMapaExistente() {
        MapaEntity guardado = mapaList.get(0);
        MapaEntity update = factory.manufacturePojo(MapaEntity.class);
        update.setRuta("Ruta Actualizada");
        update.setCoordenadasInicio("Inicio Actualizado");
        update.setCoordenadasFin("Fin Actualizado");

        MapaEntity resultado = mapaService.actualizarMapa(guardado.getId(), update);
        assertNotNull(resultado);
        assertEquals("Ruta Actualizada", resultado.getRuta());
        assertEquals("Inicio Actualizado", resultado.getCoordenadasInicio());
        assertEquals("Fin Actualizado", resultado.getCoordenadasFin());
    }

    @Test
    void testActualizarMapaInexistente() {
        MapaEntity update = factory.manufacturePojo(MapaEntity.class);
        update.setRuta("Nueva Ruta");
        MapaEntity resultado = mapaService.actualizarMapa(0L, update);
        assertNull(resultado);
    }

    @Test
    void testEliminarMapa() {
        MapaEntity entity = mapaList.get(1);
        mapaService.eliminarMapa(entity.getId());
        MapaEntity deleted = entityManager.find(MapaEntity.class, entity.getId());
        assertNull(deleted);
    }

    @Test
    void testBuscarPorRuta() {
        MapaEntity entity = mapaList.get(0);
        List<MapaEntity> resultados = mapaService.buscarPorRuta(entity.getRuta());
        assertFalse(resultados.isEmpty());
        assertEquals(entity.getRuta(), resultados.get(0).getRuta());
    }
}