package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.ClienteEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(ClienteImagenService.class)
class ClienteImagenServiceTest {

    @Autowired
    private ClienteImagenService clienteImagenService;

    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();

    private List<ClienteEntity> clientes = new ArrayList<>();
    private List<ImagenEntity> imagenes = new ArrayList<>();

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        entityManager.getEntityManager().createQuery("delete from ClienteEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
    }

    private void insertData() {
        for (int i = 0; i < 3; i++) {
            ClienteEntity cliente = factory.manufacturePojo(ClienteEntity.class);
            cliente.setIdCedula("CED" + i);
            entityManager.persist(cliente);
            clientes.add(cliente);
        }
        for (int i = 0; i < 3; i++) {
            ImagenEntity imagen = factory.manufacturePojo(ImagenEntity.class);
            imagen.setUrl("http://example.com/image" + i + ".jpg");
            entityManager.persist(imagen);
            imagenes.add(imagen);
        }
        clientes.get(0).setImagen(imagenes.get(0));
        entityManager.merge(clientes.get(0));

        clientes.get(1).setImagen(imagenes.get(1));
        entityManager.merge(clientes.get(1));
        //El tercer cliente (índice 2) no tiene imagen inicialmente
        //La tercera imagen (índice 2) no está asociada inicialmente
    }
    @Test
    void testAddImagen() throws EntityNotFoundException, IllegalOperationException {
        ImagenEntity result = clienteImagenService.addImagen(clientes.get(2).getId(), imagenes.get(2).getId());
        assertNotNull(result);
        assertEquals(imagenes.get(2).getId(), result.getId());
        assertEquals(imagenes.get(2).getUrl(), result.getUrl());
        ClienteEntity storedCliente = entityManager.find(ClienteEntity.class, clientes.get(2).getId());
        assertEquals(imagenes.get(2).getId(), storedCliente.getImagen().getId());
    }
    @Test
    void testAddImagenInvalidCliente() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.addImagen(0L, imagenes.get(2).getId());
        });
    }

    @Test
    void testAddImagenInvalidImagen() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.addImagen(clientes.get(2).getId(), 0L);
        });
    }

    @Test
    void testAddImagenWhenClienteAlreadyHasImagen() {
        assertThrows(IllegalOperationException.class, () -> {
            clienteImagenService.addImagen(clientes.get(0).getId(), imagenes.get(2).getId());
        });
    }

    @Test
    void testAddImagenWhenImagenAlreadyAssociated() {
        assertThrows(IllegalOperationException.class, () -> {
            clienteImagenService.addImagen(clientes.get(2).getId(), imagenes.get(0).getId());
        });
    }

    @Test
    void testGetImagen() throws EntityNotFoundException {
        ImagenEntity result = clienteImagenService.getImagen(clientes.get(0).getId());
        assertNotNull(result);
        assertEquals(imagenes.get(0).getId(), result.getId());
        assertEquals(imagenes.get(0).getUrl(), result.getUrl());
    }

    @Test
    void testGetImagenInvalidCliente() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.getImagen(0L);
        });
    }

    @Test
    void testGetImagenWithoutImagen() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.getImagen(clientes.get(2).getId());
        });
    }
    @Test
    void testRemoveImagen() throws EntityNotFoundException {
        clienteImagenService.removeImagen(clientes.get(0).getId());

        ClienteEntity storedCliente = entityManager.find(ClienteEntity.class, clientes.get(0).getId());
        assertNull(storedCliente.getImagen());
    }
    @Test
    void testRemoveImagenInvalidCliente() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.removeImagen(0L);
        });
    }

    @Test
    void testRemoveImagenWithoutImagen() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.removeImagen(clientes.get(2).getId());
        });
    }

    @Test
    void testReplaceImagen() throws EntityNotFoundException, IllegalOperationException {
        ImagenEntity result = clienteImagenService.replaceImagen(clientes.get(0).getId(), imagenes.get(2).getId());
        assertNotNull(result);
        assertEquals(imagenes.get(2).getId(), result.getId());
        assertEquals(imagenes.get(2).getUrl(), result.getUrl());
        ClienteEntity storedCliente = entityManager.find(ClienteEntity.class, clientes.get(0).getId());
        assertEquals(imagenes.get(2).getId(), storedCliente.getImagen().getId());
    }

    @Test
    void testReplaceImagenInvalidCliente() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.replaceImagen(0L, imagenes.get(2).getId());
        });
    }
    @Test
    void testReplaceImagenInvalidImagen() {
        assertThrows(EntityNotFoundException.class, () -> {
            clienteImagenService.replaceImagen(clientes.get(0).getId(), 0L);
        });
    }
    @Test
    void testReplaceImagenWhenImagenAlreadyAssociated() {
        assertThrows(IllegalOperationException.class, () -> {
            clienteImagenService.replaceImagen(clientes.get(0).getId(), imagenes.get(1).getId());
        });
    }
    @Test
    void testReplaceImagenWithSameImagen() throws EntityNotFoundException, IllegalOperationException {
        ImagenEntity result = clienteImagenService.replaceImagen(clientes.get(0).getId(), imagenes.get(0).getId());
        assertNotNull(result);
        assertEquals(imagenes.get(0).getId(), result.getId());
    }
}