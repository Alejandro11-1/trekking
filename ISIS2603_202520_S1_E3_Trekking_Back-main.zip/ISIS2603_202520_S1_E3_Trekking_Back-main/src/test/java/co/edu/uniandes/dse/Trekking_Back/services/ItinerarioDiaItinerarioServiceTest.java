package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(ItinerarioDiaItinerarioService.class)
class ItinerarioDiaItinerarioServiceTest {

    @Autowired
    private ItinerarioDiaItinerarioService itinerarioDiaItinerarioService;

    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();

    private ItinerarioEntity itinerario;
    private List<DiaItinerarioEntity> diasItinerario = new ArrayList<>();
    private ExpedicionEntity expedicion;
    private PersonaNaturalEntity oferente;
    private ImagenEntity imagen;

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        entityManager.getEntityManager().createQuery("delete from DiaItinerarioEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ItinerarioEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ExpedicionEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from OferenteEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
    }

    private void insertData() {
        // Imagen para el oferente
        imagen = factory.manufacturePojo(ImagenEntity.class);
        entityManager.persist(imagen);

        // Oferente
        oferente = factory.manufacturePojo(PersonaNaturalEntity.class);
        oferente.setFoto(imagen);
        entityManager.persist(oferente);

        // Mapa requerido por Expedicion
        MapaEntity mapa = factory.manufacturePojo(MapaEntity.class);
        entityManager.persist(mapa);

        // Seguridad requerida por Expedicion (campo not-null)
        SeguridadEntity seguridad = factory.manufacturePojo(SeguridadEntity.class);
        entityManager.persist(seguridad);

        // Expedición con relaciones obligatorias
        expedicion = factory.manufacturePojo(ExpedicionEntity.class);
        expedicion.setOferente(oferente);
        expedicion.setMapa(mapa);
        expedicion.setSeguridad(seguridad);
        entityManager.persist(expedicion);

        // Itinerario asociado
        itinerario = factory.manufacturePojo(ItinerarioEntity.class);
        itinerario.setExpedicion(expedicion);
        if (itinerario.getDias() == null) {
            itinerario.setDias(new ArrayList<>());
        }
        entityManager.persist(itinerario);

        if (diasItinerario == null) diasItinerario = new ArrayList<>();

        // Días del itinerario
        for (int i = 0; i < 3; i++) {
            DiaItinerarioEntity diaItinerario = factory.manufacturePojo(DiaItinerarioEntity.class);
            diaItinerario.setItinerario(itinerario);
            entityManager.persist(diaItinerario);

            diasItinerario.add(diaItinerario);
            itinerario.getDias().add(diaItinerario);
        }
    }

    @Test
    void testAddDiaItinerario() throws EntityNotFoundException {
        DiaItinerarioEntity newDiaItinerario = factory.manufacturePojo(DiaItinerarioEntity.class);
        newDiaItinerario.setItinerario(itinerario);

        entityManager.persist(newDiaItinerario);

        DiaItinerarioEntity result = itinerarioDiaItinerarioService.addDiaItinerario(itinerario.getId(), newDiaItinerario.getId());
        assertNotNull(result);
        assertEquals(newDiaItinerario.getId(), result.getId());

        DiaItinerarioEntity storedDia = entityManager.find(DiaItinerarioEntity.class, newDiaItinerario.getId());
        assertEquals(itinerario.getId(), storedDia.getItinerario().getId());
    }


    @Test
    void testAddDiaItinerarioInvalidItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            DiaItinerarioEntity newDiaItinerario = factory.manufacturePojo(DiaItinerarioEntity.class);
            newDiaItinerario.setItinerario(itinerario);
            entityManager.persist(newDiaItinerario);

            itinerarioDiaItinerarioService.addDiaItinerario(999L, newDiaItinerario.getId());
        });
    }
    @Test
    void testAddDiaItinerarioInvalidDiaItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            itinerarioDiaItinerarioService.addDiaItinerario(itinerario.getId(), 0L);
        });
        }
    @Test
    void testGetDiasItinerario() throws EntityNotFoundException {
        List<DiaItinerarioEntity> result = itinerarioDiaItinerarioService.getDiasItinerario(itinerario.getId());
        assertEquals(diasItinerario.size(), result.size());
        
        for (DiaItinerarioEntity dia : result) {
            assertTrue(diasItinerario.contains(dia));
        }
    }
    @Test
    void testGetDiasItinerarioInvalidItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            itinerarioDiaItinerarioService.getDiasItinerario(0L);
        });
    }
    @Test
    void testGetDiaItinerario() throws EntityNotFoundException, IllegalOperationException {
        DiaItinerarioEntity dia = diasItinerario.get(0);
        DiaItinerarioEntity result = itinerarioDiaItinerarioService.getDiaItinerario(itinerario.getId(), dia.getId());
        assertNotNull(result);
        assertEquals(dia.getId(), result.getId());
        assertEquals(dia.getNumeroDia(), result.getNumeroDia());
        assertEquals(dia.getDescripcion(), result.getDescripcion());
    }

    @Test
    void testGetDiaItinerarioInvalidItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            DiaItinerarioEntity dia = diasItinerario.get(0);
            itinerarioDiaItinerarioService.getDiaItinerario(0L, dia.getId());
        });
    }

    @Test
    void testGetDiaItinerarioInvalidDiaItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            itinerarioDiaItinerarioService.getDiaItinerario(itinerario.getId(), 0L);
        });
    }

    @Test
    void testReplaceDiasItinerario() throws EntityNotFoundException {
        List<DiaItinerarioEntity> nuevaLista = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            DiaItinerarioEntity dia = factory.manufacturePojo(DiaItinerarioEntity.class);
            dia.setItinerario(itinerario);

            entityManager.persist(dia);
            nuevaLista.add(dia);
        }
        
        List<DiaItinerarioEntity> result = itinerarioDiaItinerarioService.replaceDiasItinerario(itinerario.getId(), nuevaLista);
        assertEquals(nuevaLista.size(), result.size());
        
        for (DiaItinerarioEntity dia : nuevaLista) {
            assertTrue(result.contains(dia));
        }
    }

    
    @Test
    void testReplaceDiasItinerarioInvalidItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            List<DiaItinerarioEntity> nuevaLista = new ArrayList<>();
            itinerarioDiaItinerarioService.replaceDiasItinerario(0L, nuevaLista);
        });
    }

    @Test
    void testReplaceDiasItinerarioInvalidDiaItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            List<DiaItinerarioEntity> nuevaLista = new ArrayList<>();
            DiaItinerarioEntity dia = factory.manufacturePojo(DiaItinerarioEntity.class);
            dia.setId(0L);
            nuevaLista.add(dia);
            
            itinerarioDiaItinerarioService.replaceDiasItinerario(itinerario.getId(), nuevaLista);
        });
    }

    @Test
    void testRemoveDiaItinerario() throws EntityNotFoundException {
        DiaItinerarioEntity dia = diasItinerario.get(0);
        itinerarioDiaItinerarioService.removeDiaItinerario(itinerario.getId(), dia.getId());
        
        DiaItinerarioEntity storedDia = entityManager.find(DiaItinerarioEntity.class, dia.getId());
        assertNull(storedDia.getItinerario());
        
        ItinerarioEntity storedItinerario = entityManager.find(ItinerarioEntity.class, itinerario.getId());
        assertFalse(storedItinerario.getDias().contains(dia));
    }

    @Test
    void testRemoveDiaItinerarioInvalidItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            DiaItinerarioEntity dia = diasItinerario.get(0);
            itinerarioDiaItinerarioService.removeDiaItinerario(0L, dia.getId());
        });
    }

    @Test
    void testRemoveDiaItinerarioInvalidDiaItinerario() {
        assertThrows(EntityNotFoundException.class, () -> {
            itinerarioDiaItinerarioService.removeDiaItinerario(itinerario.getId(), 0L);
        });
    }
}