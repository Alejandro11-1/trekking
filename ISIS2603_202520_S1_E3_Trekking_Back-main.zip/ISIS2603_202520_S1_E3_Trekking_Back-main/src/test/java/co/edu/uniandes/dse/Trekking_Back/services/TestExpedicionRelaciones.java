package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import jakarta.persistence.PersistenceException;
import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;

@DataJpaTest
@Transactional
class TestExpedicionRelaciones {

    @Autowired
    private TestEntityManager em;

    private PersonaNaturalEntity oferenteA;

    @BeforeEach
    void init() {
        clearData();
        oferenteA = persistPersonaNatural();
    }

    private void clearData() {
        em.getEntityManager().createQuery("delete from SeguridadEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from MapaEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from ExpedicionEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from PersonaNaturalEntity").executeUpdate();
    }

    private PersonaNaturalEntity persistPersonaNatural() {
        return em.persist(new PersonaNaturalEntity());
    }

    private MapaEntity newMapa() { return new MapaEntity(); }

    private SeguridadEntity newSeguridad() { return new SeguridadEntity(); }

    /** Crea una Expedición **SIEMPRE** con mapa y seguridad (no nulos). */
    private ExpedicionEntity newExpedicion(String nombre, PersonaNaturalEntity oferente) {
        ExpedicionEntity e = new ExpedicionEntity();
        e.setNombre(nombre);
        e.setFechaInicio("2025-01-01");
        e.setFechaFin("2025-01-03");
        e.setHoraSalida("08:00");
        e.setHoraLlegada("18:00");
        e.setLugarSalida("Bogotá");
        e.setLugarLlegada("Villa de Leyva");
        e.setDuracion(2);
        e.setDescripcion("Expedición de prueba");
        e.setRecomendaciones("Ropa cómoda");
        e.setCosto(1000L);
        e.setOferente(oferente);

        // Requisitos NOT NULL del modelo:
        MapaEntity mapa = newMapa();
        e.setMapa(mapa);

        SeguridadEntity seg = newSeguridad();
        seg.setExpedicion(e);   // lado dueño de la relación si aplica en tu mapeo
        e.setSeguridad(seg);

        return e;
    }

    //  ManyToOne: Expedicion -> PersonaNatural (nullable=false)

    @Test
    void whenPersistExpedicion_withOferente_ok() {
        ExpedicionEntity e = newExpedicion("Exp A", oferenteA);
        e = em.persistFlushFind(e);

        assertNotNull(e.getId());
        assertNotNull(e.getOferente());
        assertEquals(oferenteA.getId(), e.getOferente().getId());
    }

    @Test
    void whenPersistExpedicion_withoutOferente_throws() {
        // Dejar mapa/seguridad válidos para que el fallo sea por oferente null
        ExpedicionEntity e = newExpedicion("Exp B", null);
        assertThrows(PersistenceException.class, () -> {
            em.persist(e);
            em.flush();
        });
    }

    // OneToOne: Expedicion -> Mapa (cascade = ALL, orphanRemoval = true)

    @Test
    void oneToOne_mapa_persistsByCascade_andLoads() {
        ExpedicionEntity e = newExpedicion("Exp M", oferenteA);
        // Ya viene con mapa/seguridad no nulos por newExpedicion()
        e = em.persistFlushFind(e);
        assertNotNull(e.getMapa());
        assertNotNull(e.getMapa().getId());
    }

    @Test
    void oneToOne_mapa_replace_orphanIsDeleted() {
        ExpedicionEntity e = newExpedicion("Exp M2", oferenteA);
        e = em.persistFlushFind(e);

        Long oldMapaId = e.getMapa().getId();
        e.setMapa(newMapa());
        e = em.persistFlushFind(e);

        assertNotNull(e.getMapa());
        assertNotNull(e.getMapa().getId());
        assertNotEquals(oldMapaId, e.getMapa().getId());

        Long countOld = em.getEntityManager()
                .createQuery("select count(m) from MapaEntity m where m.id = :id", Long.class)
                .setParameter("id", oldMapaId)
                .getSingleResult();
        assertEquals(0L, countOld);
    }

    //  Delete checks

    @Test
    void deleteExpedicion_cascadesToMapaAndSeguridad_butNotOferente() {
        ExpedicionEntity e = newExpedicion("Exp DEL", oferenteA);
        e = em.persistFlushFind(e);

        Long mapaId = e.getMapa().getId();
        Long segId = e.getSeguridad().getId();
        Long oferenteId = e.getOferente().getId();

        em.remove(e);
        em.flush();

        // mapa y seguridad deben desaparecer
        Long cMapa = em.getEntityManager().createQuery(
                "select count(m) from MapaEntity m where m.id=:id", Long.class)
                .setParameter("id", mapaId).getSingleResult();
        Long cSeg = em.getEntityManager().createQuery(
                "select count(sg) from SeguridadEntity sg where sg.id=:id", Long.class)
                .setParameter("id", segId).getSingleResult();

        assertEquals(0L, cMapa);
        assertEquals(0L, cSeg);

        // Según tu mapeo actual, eliminar Expedicion también elimina Oferente (cascade REMOVE en @ManyToOne)
        Long cOfer = em.getEntityManager().createQuery(
                "select count(o) from PersonaNaturalEntity o where o.id=:id", Long.class)
                .setParameter("id", oferenteId).getSingleResult();
        assertEquals(0L, cOfer);
    }
}
