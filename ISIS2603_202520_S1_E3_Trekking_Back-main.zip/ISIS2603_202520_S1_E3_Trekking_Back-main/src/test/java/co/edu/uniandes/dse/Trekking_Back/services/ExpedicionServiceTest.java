package co.edu.uniandes.dse.Trekking_Back.services;

import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;

import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Set;

import uk.co.jemos.podam.api.PodamFactoryImpl;
import uk.co.jemos.podam.api.PodamFactory;

@DataJpaTest
@Transactional
@Import(ExpedicionService.class)
class ExpedicionServiceTest {

    @Autowired
    private ExpedicionService expedicionService;

    @Autowired
    private TestEntityManager entityManager;

    private ExpedicionEntity expedicion1, expedicion2, expedicion3;

    private final PodamFactory factory = new PodamFactoryImpl();

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        entityManager.getEntityManager().createQuery("delete from ExpedicionEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from SeguridadEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from MapaEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from PersonaNaturalEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
    }

    private PersonaNaturalEntity crearOferente(String nombre, String apellido, int cedula) {
        PersonaNaturalEntity p = new PersonaNaturalEntity();
        p.setNombre(nombre);
        p.setApellido(apellido);
        p.setIdCedula(String.valueOf(cedula)); // convertir a String
        return p;
    }

    private PersonaNaturalEntity crearOferenteConFoto() {
        ImagenEntity img = factory.manufacturePojo(ImagenEntity.class);
        entityManager.persist(img);
    
        PersonaNaturalEntity ofer = factory.manufacturePojo(PersonaNaturalEntity.class);
        ofer.setFoto(img);
        entityManager.persist(ofer);
        return ofer;
    }

    private void setRequeridos(ExpedicionEntity e) {
        MapaEntity mapa = factory.manufacturePojo(MapaEntity.class);
        entityManager.persist(mapa);
    
        SeguridadEntity seguridad = factory.manufacturePojo(SeguridadEntity.class);
        entityManager.persist(seguridad);
    
        e.setMapa(mapa);
        e.setSeguridad(seguridad);
    }

    private ExpedicionEntity nuevaExp(String nombre, int costo, PersonaNaturalEntity oferente) {
        ExpedicionEntity e = new ExpedicionEntity();
        e.setNombre(nombre);
        e.setFechaInicio("2025-01-01");
        e.setFechaFin("2025-01-05");
        e.setHoraSalida("08:00");
        e.setHoraLlegada("17:00");
        e.setLugarSalida("Origen");
        e.setLugarLlegada("Destino");
        e.setDuracion(4);
        e.setDescripcion("Desc");
        e.setRecomendaciones("Recs");
        e.setCosto((long) costo);
        e.setOferente(oferente);
    
        // relaciones obligatorias
        setRequeridos(e);
        return e;
    }

    private void insertData() {
        for (int i = 0; i < 3; i++) {
            ExpedicionEntity exp = factory.manufacturePojo(ExpedicionEntity.class);
    
            // oferente ÚNICO por expedición
            PersonaNaturalEntity oferente = crearOferenteConFoto();
            exp.setOferente(oferente);
    
            // relaciones obligatorias ÚNICAS
            setRequeridos(exp);
    
            // costos fijos para las pruebas
            if (i == 0) exp.setCosto(3000L);
            if (i == 1) exp.setCosto(5000L); // la que cae en el rango 4000–6000
            if (i == 2) exp.setCosto(9000L);
    
            entityManager.persist(exp);
    
            if (i == 0) expedicion1 = exp;
            if (i == 1) expedicion2 = exp;
            if (i == 2) expedicion3 = exp;
        }
    }

    // PRUEBAS DE CREACION

    @Test
    void crearExpedicion_ok() throws IllegalOperationException {
        PersonaNaturalEntity oferente = entityManager.persist(crearOferente("Ana", "Pérez", 4567));

        ExpedicionEntity nueva = new ExpedicionEntity();
        nueva.setNombre("Cañón del Chicamocha");
        nueva.setFechaInicio("2025-04-01");
        nueva.setFechaFin("2025-04-04");
        nueva.setHoraSalida("09:00");
        nueva.setHoraLlegada("17:30");
        nueva.setLugarSalida("Bucaramanga");
        nueva.setLugarLlegada("San Gil");
        nueva.setDuracion(3);
        nueva.setDescripcion("Descenso por el cañón.");
        nueva.setRecomendaciones("Bloqueador solar.");
        nueva.setCosto(2500L);
        nueva.setOferente(oferente);

        // relaciones obligatorias
        setRequeridos(nueva);

        ExpedicionEntity creada = expedicionService.crearExpedicion(nueva);
        assertNotNull(creada.getId());
        assertEquals("Cañón del Chicamocha", creada.getNombre());
        assertEquals(oferente.getId(), creada.getOferente().getId());
    }

    @Test
    void crearExpedicion_nombreInvalido_lanzaExcepcion() {
        PersonaNaturalEntity oferente = entityManager.persist(crearOferente("Ana", "Pérez", 5678));

        ExpedicionEntity e = nuevaExp("X", 100, oferente);
        e.setNombre(null);

        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e));
    }

    @Test
    void crearExpedicion_fechasYLugaresYCostosInvalidos_lanzaExcepcion() {
        PersonaNaturalEntity oferente = entityManager.persist(crearOferente("Ana", "Pérez", 6789));

        ExpedicionEntity e1 = nuevaExp("Valida", 100, oferente);
        e1.setFechaInicio("");
        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e1));

        ExpedicionEntity e2 = nuevaExp("Valida", 100, oferente);
        e2.setFechaFin("");
        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e2));

        ExpedicionEntity e3 = nuevaExp("Valida", 100, oferente);
        e3.setLugarSalida("");
        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e3));

        ExpedicionEntity e4 = nuevaExp("Valida", 100, oferente);
        e4.setLugarLlegada("");
        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e4));

        ExpedicionEntity e5 = nuevaExp("Valida", -10, oferente);
        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e5));

        ExpedicionEntity e6 = nuevaExp("Valida", 100, oferente);
        e6.setDuracion(0);
        assertThrows(IllegalOperationException.class, () -> expedicionService.crearExpedicion(e6));
    }

    // PRUEBAS DE BUSQUEDA

    @Test
    void getExpedicionPorId_ok() throws EntityNotFoundException {
        ExpedicionEntity encontrada = expedicionService.getExpedicionPorId(expedicion1.getId());
        assertEquals(expedicion1.getNombre(), encontrada.getNombre());
    }

    @Test
    void getExpedicionPorId_noExiste_lanzaExcepcion() {
        assertThrows(EntityNotFoundException.class, () -> expedicionService.getExpedicionPorId(999999L));
    }

    @Test
    void getExpedicionPorNombre_ok() throws EntityNotFoundException {
        ExpedicionEntity encontrada = expedicionService.getExpedicionPorNombre(expedicion2.getNombre());
        assertEquals(expedicion2.getId(), encontrada.getId());
    }

    @Test
    void getExpedicionPorNombre_noExiste_lanzaExcepcion() {
        assertThrows(EntityNotFoundException.class, () -> expedicionService.getExpedicionPorNombre("Nombre Inexistente"));
    }

    @Test
    void getExpedicionPorPrecio_enRango_ok() throws EntityNotFoundException {
        ExpedicionEntity encontrada = expedicionService.getExpedicionPorPrecio(4000L, 6000L);
        assertEquals(5000L, encontrada.getCosto());
    }

    @Test
    void getExpedicionPorPrecio_sinResultados_lanzaExcepcion() {
        assertThrows(EntityNotFoundException.class, () -> expedicionService.getExpedicionPorPrecio(11000L, 12000L));
    }

    @Test
    void getExpediciones_ok() {
        List<ExpedicionEntity> todas = expedicionService.getExpediciones();

        assertNotNull(todas);
        assertEquals(3, todas.size(), "Debe traer las 3 expediciones cargadas en insertData()");

        // El orden de findAll() no está garantizado: validamos por IDs
        Set<Long> ids = todas.stream().map(ExpedicionEntity::getId).collect(Collectors.toSet());
        assertTrue(ids.containsAll(List.of(expedicion1.getId(), expedicion2.getId(), expedicion3.getId())),
                "La lista debe contener e1, e2 y e3");
    }

    @Test
    void getExpediciones_sinDatos_retornaListaVacia() {
        clearData();
        entityManager.flush();

        List<ExpedicionEntity> todas = expedicionService.getExpediciones();

        assertNotNull(todas);
        assertTrue(todas.isEmpty(), "Con la BD vacía debe devolver lista vacía");
    }

    // PRUEBAS DE ACTUALIZACION

    @Test
    void updateExpedicion_ok() throws EntityNotFoundException {
        Long id = expedicion3.getId();

        ExpedicionEntity cambios = new ExpedicionEntity();
        cambios.setNombre("Selva Profunda (Actualizada)");
        cambios.setFechaInicio("2025-03-11");
        cambios.setFechaFin("2025-03-21");
        cambios.setHoraSalida("07:30");
        cambios.setHoraLlegada("16:30");
        cambios.setLugarSalida("Leticia");
        cambios.setLugarLlegada("Reserva Natural");
        cambios.setDuracion(11);
        cambios.setDescripcion("Exploración en selva húmeda ACT.");
        cambios.setRecomendaciones("Repelente, impermeable ACT.");
        cambios.setCosto(9500L);
        cambios.setOferente(expedicion3.getOferente());

        ExpedicionEntity actualizada = expedicionService.updateExpedicion(id, cambios);

        assertEquals(id, actualizada.getId());
        assertEquals("Selva Profunda (Actualizada)", actualizada.getNombre());
        assertEquals(9500L, actualizada.getCosto());
    }

    @Test
    void updateExpedicion_noExiste_lanzaExcepcion() {
        PersonaNaturalEntity oferente = entityManager.persist(crearOferente("Ana", "Pérez", 7890));
        ExpedicionEntity cambios = nuevaExp("Valida", 100, oferente);
        assertThrows(EntityNotFoundException.class, () -> expedicionService.updateExpedicion(123456L, cambios));
    }

    // PRUEBAS DE ELIMINACION

    @Test
    void deleteExpedicion_ok() throws EntityNotFoundException {
        Long id = expedicion1.getId();
        expedicionService.deleteExpedicion(id);
        assertThrows(EntityNotFoundException.class, () -> expedicionService.getExpedicionPorId(id));
    }

    @Test
    void deleteExpedicion_noExiste_lanzaExcepcion() {
        assertThrows(EntityNotFoundException.class, () -> expedicionService.deleteExpedicion(777777L));
    }
}