package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import jakarta.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;

import co.edu.uniandes.dse.Trekking_Back.entities.DiaItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ExpedicionEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ItinerarioEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.MapaEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.PersonaNaturalEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.SeguridadEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;

@DataJpaTest
@Transactional
@Import(DiaItinerarioService.class)
class DiaItinerarioServiceTest {

    @Autowired
    private DiaItinerarioService diaService;

    @Autowired
    private TestEntityManager em;

    private ItinerarioEntity iti1;
    private ItinerarioEntity iti2;
    private DiaItinerarioEntity d1, d2, d3;

    @BeforeEach
    void setUp() {
        clearData();
        insertData();
    }

    private void clearData() {
        em.getEntityManager().createQuery("delete from DiaItinerarioEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from ItinerarioEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from ExpedicionEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from SeguridadEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from MapaEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from PersonaNaturalEntity").executeUpdate();
        em.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
    }

    private PersonaNaturalEntity persistOferenteConFoto() {
        ImagenEntity img = new ImagenEntity();
        em.persist(img);

        PersonaNaturalEntity p = new PersonaNaturalEntity();
        p.setFoto(img);
        return em.persist(p);
    }

    private ExpedicionEntity persistExpedicionValida() {
        PersonaNaturalEntity oferente = persistOferenteConFoto();

        MapaEntity mapa = new MapaEntity();
        em.persist(mapa);

        SeguridadEntity seg = new SeguridadEntity();
        em.persist(seg);

        ExpedicionEntity e = new ExpedicionEntity();
        e.setNombre("Exp Base");
        e.setFechaInicio("2025-01-01");
        e.setFechaFin("2025-01-05");
        e.setHoraSalida("08:00");
        e.setHoraLlegada("17:00");
        e.setLugarSalida("Origen");
        e.setLugarLlegada("Destino");
        e.setDuracion(4);
        e.setDescripcion("Desc");
        e.setRecomendaciones("Recs");
        e.setCosto(1000L);
        e.setOferente(oferente);
        e.setMapa(mapa);
        e.setSeguridad(seg);

        return em.persist(e);
    }

    private ItinerarioEntity persistItinerario(ExpedicionEntity exp, String nombre) {
        ItinerarioEntity iti = new ItinerarioEntity();
        iti.setNombre(nombre);
        iti.setExpedicion(exp);
        return em.persist(iti);
    }

    private DiaItinerarioEntity persistDia(ItinerarioEntity iti, int numeroDia, String descripcion) {
        DiaItinerarioEntity d = new DiaItinerarioEntity();
        d.setNumeroDia(numeroDia);
        d.setDescripcion(descripcion);
        d.setItinerario(iti);
        return em.persist(d);
    }

    private void insertData() {
        ExpedicionEntity exp1 = persistExpedicionValida();
        ExpedicionEntity exp2 = persistExpedicionValida();

        iti1 = persistItinerario(exp1, "Itinerario 1");
        iti2 = persistItinerario(exp2, "Itinerario 2");

        d1 = persistDia(iti1, 1, "Día de aclimatación");
        d2 = persistDia(iti1, 2, "Ascenso");
        d3 = persistDia(iti2, 1, "Caminata suave");

        em.flush();
        em.clear();
    }

    // CREAR

    @Test
    void crearDia_ok() throws IllegalOperationException {
        DiaItinerarioEntity nuevo = new DiaItinerarioEntity();
        nuevo.setNumeroDia(3);
        nuevo.setDescripcion("Cumbre");
        nuevo.setItinerario(iti1);

        DiaItinerarioEntity creado = diaService.crearDia(nuevo);

        assertNotNull(creado.getId());
        assertEquals(3, creado.getNumeroDia());
        assertEquals("Cumbre", creado.getDescripcion());
        assertEquals(iti1.getId(), creado.getItinerario().getId());
    }

    @Test
    void crearDia_numeroInvalido_lanzaExcepcion() {
        DiaItinerarioEntity dia = new DiaItinerarioEntity();
        dia.setNumeroDia(0);
        dia.setItinerario(iti1);

        assertThrows(IllegalOperationException.class, () -> diaService.crearDia(dia));
    }

    @Test
    void crearDia_sinItinerario_lanzaExcepcion() {
        DiaItinerarioEntity dia = new DiaItinerarioEntity();
        dia.setNumeroDia(1);
        dia.setItinerario(null);

        assertThrows(IllegalOperationException.class, () -> diaService.crearDia(dia));
    }

    // GET por id / filtros

    @Test
    void getDiaPorId_ok() throws EntityNotFoundException {
        DiaItinerarioEntity encontrado = diaService.getDiaPorId(d1.getId());
        assertEquals(d1.getDescripcion(), encontrado.getDescripcion());
        assertEquals(d1.getNumeroDia(), encontrado.getNumeroDia());
    }

    @Test
    void getDiaPorId_noExiste_lanzaExcepcion() {
        assertThrows(EntityNotFoundException.class, () -> diaService.getDiaPorId(999999L));
    }

    @Test
    void getDiasPorDescripcion_ok() {
        List<DiaItinerarioEntity> lista = diaService.getDiasPorDescripcion("Ascenso");
        assertEquals(1, lista.size());
        assertEquals(d2.getId(), lista.get(0).getId());
    }

    @Test
    void getDiasPorItinerario_ok() throws IllegalOperationException {
        List<DiaItinerarioEntity> lista = diaService.getDiasPorItinerario(iti1);
        // iti1 tiene d1 y d2
        assertEquals(2, lista.size());
    }

    @Test
    void getDiasPorItinerario_null_lanzaExcepcion() {
        assertThrows(IllegalOperationException.class, () -> diaService.getDiasPorItinerario(null));
    }

    // UPDATE

    @Test
    void updateDia_ok() throws EntityNotFoundException, IllegalOperationException {
        DiaItinerarioEntity cambios = new DiaItinerarioEntity();
        cambios.setNumeroDia(5);
        cambios.setDescripcion("Día actualizado");
        cambios.setItinerario(iti2); // mover al otro itinerario

        DiaItinerarioEntity actualizado = diaService.updateDia(d1.getId(), cambios);

        assertEquals(d1.getId(), actualizado.getId());
        assertEquals(5, actualizado.getNumeroDia());
        assertEquals("Día actualizado", actualizado.getDescripcion());
        assertEquals(iti2.getId(), actualizado.getItinerario().getId());
    }

    @Test
    void updateDia_noExiste_lanzaExcepcion() {
        DiaItinerarioEntity cambios = new DiaItinerarioEntity();
        cambios.setNumeroDia(2);
        cambios.setDescripcion("X");
        cambios.setItinerario(iti1);

        assertThrows(EntityNotFoundException.class, () -> diaService.updateDia(123456L, cambios));
    }

    @Test
    void updateDia_numeroInvalido_lanzaExcepcion() {
        DiaItinerarioEntity cambios = new DiaItinerarioEntity();
        cambios.setNumeroDia(0);
        cambios.setDescripcion("X");
        cambios.setItinerario(iti1);

        assertThrows(IllegalOperationException.class, () -> diaService.updateDia(d2.getId(), cambios));
    }

    @Test
    void updateDia_sinItinerario_lanzaExcepcion() {
        DiaItinerarioEntity cambios = new DiaItinerarioEntity();
        cambios.setNumeroDia(2);
        cambios.setDescripcion("X");
        cambios.setItinerario(null);

        assertThrows(IllegalOperationException.class, () -> diaService.updateDia(d2.getId(), cambios));
    }

    // DELETE

    @Test
    void deleteDia_ok() throws EntityNotFoundException {
        Long id = d3.getId();
        diaService.deleteDia(id);

        assertThrows(EntityNotFoundException.class, () -> diaService.getDiaPorId(id));
    }

    @Test
    void deleteDia_noExiste_lanzaExcepcion() {
        assertThrows(EntityNotFoundException.class, () -> diaService.deleteDia(777777L));
    }
}
