package co.edu.uniandes.dse.Trekking_Back.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.Transactional;

import co.edu.uniandes.dse.Trekking_Back.entities.ClienteEntity;
import co.edu.uniandes.dse.Trekking_Back.entities.ImagenEntity;
import co.edu.uniandes.dse.Trekking_Back.exceptions.EntityNotFoundException;
import co.edu.uniandes.dse.Trekking_Back.exceptions.IllegalOperationException;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

@DataJpaTest
@Transactional
@Import(ClienteService.class)
class ClienteServiceTest {
    @Autowired
    private ClienteService clienteService;
    @Autowired
    private TestEntityManager entityManager;

    private PodamFactory factory = new PodamFactoryImpl();

    private List<ClienteEntity> clienteList = new ArrayList<>();
    private List<ImagenEntity> imagenList = new ArrayList<>();

    @BeforeEach
    void setUp(){
        clearData();
        insertData();
    }
    
    private void clearData(){
        entityManager.getEntityManager().createQuery("delete from ClienteEntity").executeUpdate();
        entityManager.getEntityManager().createQuery("delete from ImagenEntity").executeUpdate();
        clienteList.clear();
        imagenList.clear();
    }
    
    private void insertData(){
        for (int i = 0; i < 3; i++){
            ImagenEntity imagen = factory.manufacturePojo(ImagenEntity.class);
            entityManager.persist(imagen);
            imagenList.add(imagen);
            
            ClienteEntity cliente = factory.manufacturePojo(ClienteEntity.class);
            cliente.setIdCedula("CED" + i);
            cliente.setImagen(imagen);
            
            entityManager.persist(cliente);
            clienteList.add(cliente);
        }
    }
    
    @Test
    void testCrearCliente() throws IllegalOperationException{
        ImagenEntity nuevaImagen = factory.manufacturePojo(ImagenEntity.class);
        entityManager.persist(nuevaImagen);
        
        ClienteEntity newCliente = factory.manufacturePojo(ClienteEntity.class);
        newCliente.setIdCedula("CED100");
        newCliente.setImagen(nuevaImagen);
        
        ClienteEntity resultado = clienteService.createCliente(newCliente);
        assertNotNull(resultado);

        ClienteEntity entity = entityManager.find(ClienteEntity.class, resultado.getId());
        assertEquals(newCliente.getNombre(), entity.getNombre());
        assertEquals(newCliente.getIdCedula(), entity.getIdCedula());
        assertEquals(newCliente.getImagen().getId(), entity.getImagen().getId());
    }
    
    @Test
    void testCrearClienteConCedulaDuplicada() {
        assertThrows(IllegalOperationException.class, () -> {
            ImagenEntity nuevaImagen = factory.manufacturePojo(ImagenEntity.class);
            entityManager.persist(nuevaImagen);
            
            ClienteEntity newCliente = factory.manufacturePojo(ClienteEntity.class);
            newCliente.setIdCedula(clienteList.get(0).getIdCedula());
            newCliente.setImagen(nuevaImagen);
            
            clienteService.createCliente(newCliente);
        });
    }
    
    @Test
    void testCrearClienteSinImagen() {
        assertThrows(IllegalOperationException.class, () -> {
            ClienteEntity newCliente = factory.manufacturePojo(ClienteEntity.class);
            newCliente.setIdCedula("CED100");
            newCliente.setImagen(null);
            
            clienteService.createCliente(newCliente);
        });
    }

    @Test
    void testGetCliente() throws EntityNotFoundException {
        ClienteEntity entity = clienteList.get(0);
        ClienteEntity resultEntity = clienteService.getCliente(entity.getId());
        assertNotNull(resultEntity);
        assertEquals(entity.getId(), resultEntity.getId());
        assertEquals(entity.getNombre(), resultEntity.getNombre());
        assertEquals(entity.getCorreo(), resultEntity.getCorreo());
        assertEquals(entity.getContrasena(), resultEntity.getContrasena());
        assertEquals(entity.getIdCedula(), resultEntity.getIdCedula());
        assertEquals(entity.getImagen().getId(), resultEntity.getImagen().getId());
    }

    @Test
    void testGetClientes() {
        List<ClienteEntity> list = clienteService.getClientes();
        assertEquals(clienteList.size(), list.size());
        for (ClienteEntity entity : list) {
            boolean found = false;
            for (ClienteEntity storedEntity : clienteList) {
                if (entity.getId().equals(storedEntity.getId())) {
                    found = true;
                }
            }
            assertTrue(found);
        }
    }
    
    @Test
    void testGetInvalidCliente() {
        assertThrows(EntityNotFoundException.class, () -> clienteService.getCliente(0L));
    }

    @Test
    void testUpdateCliente() throws EntityNotFoundException, IllegalOperationException {
        ClienteEntity guardado = clienteList.get(0);
        ClienteEntity update = factory.manufacturePojo(ClienteEntity.class);
        update.setNombre("Nuevo Nombre");
        update.setIdCedula("CED200");
        update.setImagen(guardado.getImagen()); 

        ClienteEntity resultado = clienteService.updateCliente(guardado.getId(), update);
        assertEquals("CED200", resultado.getIdCedula());
        assertEquals("Nuevo Nombre", resultado.getNombre());
        assertEquals(guardado.getImagen().getId(), resultado.getImagen().getId());
    }
    
    @Test
    void testUpdateClienteConCedulaDuplicada() {
        assertThrows(IllegalOperationException.class, () -> {
            ClienteEntity guardado = clienteList.get(0);
            ClienteEntity update = factory.manufacturePojo(ClienteEntity.class);
            update.setIdCedula(clienteList.get(1).getIdCedula());
            update.setImagen(guardado.getImagen());
            
            clienteService.updateCliente(guardado.getId(), update);
        });
    }
    
    @Test
    void testDeleteCliente() throws EntityNotFoundException, IllegalOperationException {
        ClienteEntity entity = clienteList.get(1);
        clienteService.deleteCliente(entity.getId());
        ClienteEntity deleted = entityManager.find(ClienteEntity.class, entity.getId());
        assertNull(deleted);
    }
    
    @Test
    void testDeleteInvalidCliente() {
        assertThrows(EntityNotFoundException.class, () -> clienteService.deleteCliente(0L));
    }
}